<?php session_start();
require 'conexion.php';
if (isset($_SESSION['usuario'])) {
    header('location: panel/index.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $correo = $_POST['correo'];
    $clave = $_POST['clave'];
    $clave = hash('sha512', $clave);
    $error = '';

    
  

    $statement = $conexion->prepare(
        '
        SELECT * FROM usuarios WHERE correo = :correo AND clave = :clave AND estatus_actual_id != 3 AND estatus_actual_id != 4'
    );

    $statement->execute(array(
        ':correo' => $correo,
        ':clave' => $clave
    ));

    $resultado = $statement->fetch();

    if ($resultado !== false) {
        $_SESSION['usuario'] = $correo;
        header('location: panel/index.php');
    } else {

        $statement = $conexion->prepare(
            '
            SELECT * FROM administrador WHERE correo = :correo AND clave = :clave'
        );

        $statement->execute(array(
            ':correo' => $correo,
            ':clave' => $clave
        ));

        $resultado = $statement->fetch();

        if ($resultado !== false) {

            $_SESSION['administrador'] = $correo;
            header('location: panel/administrador.php');
        } else {
            $error .= '<i style="color: red;">Este usuario no existe</i>';
        }
    }
}
require 'sesion.php';
