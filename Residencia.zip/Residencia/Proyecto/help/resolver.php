<?php
          require '../vendor/autoload.php';
          $id = $_GET['id'];
          $resolver = new fundacion\Ayuda;
          $info_resolver= $resolver->resolver($id);
          header('Location: index.php');    
         
?>