<?php session_start();

if (isset($_SESSION['administrador'])) {

    require '../conexion.php';
    $email_sesion = $_SESSION['administrador'];
    $query_sesion = $conexion->prepare("SELECT * FROM administrador WHERE correo ='$email_sesion'");
    $query_sesion->execute();
    $sesion_administradores = $query_sesion->fetchAll(PDO::FETCH_ASSOC);
    foreach ($sesion_administradores as $sesion_administrador) {
        $sobrenombre = $sesion_administrador['sobrenombre'];
    }

?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Fundación Albornoz Jiménez A.C.</title>

        <!-- CSS -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/estilos.css">
        <link rel="shorcut icon" type="image/x-icon" href="../assets/imagenes/Fundacion.ico">
    </head>

    <body>

        <!-- Fixed navbar -->
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">Regresar</a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav pull-right">
                        <li class="active" class="dropdown">
                            <a href="index.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Ayuda<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="index.php">General</a></li>
                                <li><a href="procesando.php">Procesando</a></li>
                                <li><a href="resueltos.php">Resueltos</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $sobrenombre ?> <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="../panel/administrador/actualizar_administrador.php">Mis datos</a></li>
                                <li><a href="../panel/administrador/actualizar_clave.php">Cambiar contraseña</a></li>
                                <li><a href="../Cerrar_session.php">Salir</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <!--/.nav-collapse -->
            </div>
        </nav>



        <?php
        require '../vendor/autoload.php';
        $ayuda = new fundacion\Ayuda;
        //por estatus
        $general = $ayuda->graficageneral();
        $enespera = $ayuda->graficaenespera();
        $procesando = $ayuda->graficaprocesando();
        $resuelto = $ayuda->graficaresueltos();

        $grafica_g = ((float)$general * 100) / $general; //regla de tres
        $grafica_g = round($grafica_g, 0); // Quitar los decimales
        $grafica_e = ((float)$enespera * 100) / $general;
        $grafica_e = round($grafica_e, 0);
        $grafica_p = ((float)$procesando * 100) / $general;
        $grafica_p = round($grafica_p, 0);
        $grafica_r = ((float)$resuelto * 100) / $general;
        $grafica_r = round($grafica_r, 0);
        //por categoria
        $accesoalacuenta = $ayuda->graficaaccesoalacuenta();
        $problematecnico = $ayuda->graficaproblematecnico();
        $cuentacancelada = $ayuda->graficacuentacancelada();
        $opiniones = $ayuda->graficaopiniones();
        $otrosmotivos = $ayuda->graficaotrosmotivos();

        $grafica_ac = ((float)$accesoalacuenta * 100) / $general; //regla de tres
        $grafica_ac = round($grafica_ac, 0); // Quitar los decimales
        $grafica_pt = ((float)$problematecnico * 100) / $general;
        $grafica_pt = round($grafica_pt, 0);
        $grafica_cc = ((float)$cuentacancelada * 100) / $general;
        $grafica_cc = round($grafica_cc, 0);
        $grafica_o = ((float)$opiniones * 100) / $general;
        $grafica_o = round($grafica_o, 0);
        $grafica_m = ((float)$otrosmotivos * 100) / $general;
        $grafica_m = round($grafica_m, 0);

        ?>
        <div class="container px-5 px-lg-5 mt-5" id="main">
            <div class="row gx-5 gx-lg-5 row-cols-2 justify-content-center">
                <!--cards / Grafica por estatus-->
                <div class="col 12 ">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-info">
                            <h3 class=" text-center ">Grafica de ayuda por estatus</h3>
                        </div>
                        <!--Grafica general-->
                        <div class="class= card h-100">
                            <div class="card-body p-4 ">
                                <div class="h4 container px-4 px-lg-5 mt-5" align="justify">
                                    <label>Total de reportes = <?php print $general ?></label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-danger progress-bar-striped" title="<?php echo $grafica_e ?>%" style='width: <?php echo $grafica_e ?>%'>
                                        </div>
                                        <div class="progress-bar progress-bar-warning progress-bar-striped" title="<?php echo $grafica_p ?>%" style='width: <?php echo $grafica_p ?>%'>
                                        </div>
                                        <div class="progress-bar progress-bar-success progress-bar-striped" title="<?php echo $grafica_r ?>%" style='width: <?php echo $grafica_r ?>%'>
                                        </div>
                                    </div>
                                    <!--Graficas individuales-->
                                    <label>Reportes en espera <?php print $enespera ?> = <?php print $grafica_e ?> %</label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style='width: <?php echo $grafica_e ?>%'>
                                        </div>
                                    </div>
                                    <label>Reportes en proceso <?php print $procesando ?> = <?php print $grafica_p ?> % </label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style='width: <?php echo $grafica_p ?>%'>
                                            <span class="sr-only">60% Complete (warning)</span>
                                        </div>
                                    </div>
                                    <label>Reportes resueltos <?php print $resuelto ?> = <?php print $grafica_r ?> %</label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style='width: <?php echo $grafica_r ?>%'>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--cards / Grafica por categoria-->

                    <div class="panel panel-default">
                        <div class="panel-heading panel-info">
                            <h3 class=" text-center ">Grafica de ayuda por categoría</h3>
                        </div>
                        <!--Grafica general-->
                        <div class="class= card h-100">
                            <div class="card-body p-4 ">
                                <div class="h4 container px-4 px-lg-5 mt-5" align="justify">
                                    <label>Total de reportes = <?php print $general ?></label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-danger progress-bar-striped" title="<?php echo $grafica_pt ?>%" style='width: <?php echo $grafica_pt ?>%'>
                                        </div>
                                        <div class="progress-bar progress-bar-warning progress-bar-striped" title="<?php echo $grafica_ac ?>%" style='width: <?php echo $grafica_ac ?>%'>
                                        </div>
                                        <div class="progress-bar progress-bar-info progress-bar-striped" title="<?php echo $grafica_cc ?>%" style='width: <?php echo $grafica_cc ?>%'>
                                        </div>
                                        <div class="progress-bar progress-bar-success progress-bar-striped" title="<?php echo $grafica_o ?>%" style='width: <?php echo $grafica_o ?>%'>
                                        </div>
                                        <div class="progress-bar progress-bar-default progress-bar-striped" title="<?php echo $grafica_m ?>%" style='width: <?php echo $grafica_m ?>%'>
                                        </div>
                                    </div>
                                    <!--Graficas individuales-->
                                    <label>Error o problema tecnico <?php print $problematecnico ?> = <?php print $grafica_pt ?> %</label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style='width: <?php echo $grafica_pt ?>%'>
                                        </div>
                                    </div>
                                    <label>Acceso a la cuenta <?php print $accesoalacuenta ?> = <?php print $grafica_ac ?> %</label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style='width: <?php echo $grafica_ac ?>%'>
                                        </div>
                                    </div>

                                    <label>La cuenta ha sido cancelada <?php print $cuentacancelada ?> = <?php print $grafica_cc ?> % </label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style='width: <?php echo $grafica_cc ?>%'>

                                        </div>
                                    </div>
                                    <label>Opiniones y comentarios <?php print $opiniones ?> = <?php print $grafica_o ?> %</label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style='width: <?php echo $grafica_o ?>%'>
                                        </div>
                                    </div>
                                    <label>Otros motivos <?php print $otrosmotivos ?> = <?php print $grafica_m ?> %</label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-default" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style='width: <?php echo $grafica_m ?>%'>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </body>
    <!-- JavaScript -->
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>

    </html>
<?php
} else {
    header('Location: ../login.php');
    die();
}

?>