<?php
          require '../vendor/autoload.php';
          $id = $_GET['id'];
          $procesar = new fundacion\Ayuda;
          $info_procesar= $procesar->procesar($id);
          header('Location: index.php');    
         
?>