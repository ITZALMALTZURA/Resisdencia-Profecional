-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 03-02-2022 a las 16:28:57
-- Versión del servidor: 10.5.12-MariaDB
-- Versión de PHP: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `id18011743_fundacion`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administrador`
--

CREATE TABLE `administrador` (
  `id` int(11) NOT NULL,
  `nombre_usuario` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `sobrenombre` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(320) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` int(10) NOT NULL,
  `direccion` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `clave` varchar(500) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `administrador`
--

INSERT INTO `administrador` (`id`, `nombre_usuario`, `sobrenombre`, `correo`, `telefono`, `direccion`, `clave`) VALUES
(12, 'Fundacion Albornoz Jimenez ', 'FAJ', 'fundacionalbornozjimenez@gmail.com', 12345678, 'conocido', '1af247e88db0afe0fa886fc2b943da6c0160fb6f8931f08d4338ad2e00de79d3b6707f6c8ff9f9f9d2224926cc8e0f2c3ab83bcbb657b987189dbf00470b4d48');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ayuda`
--

CREATE TABLE `ayuda` (
  `id` int(11) NOT NULL,
  `categoria_id` int(2) NOT NULL,
  `descripcion` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `foto` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `correo` varchar(320) COLLATE utf8_unicode_ci NOT NULL,
  `estatus_id` int(1) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `ayuda`
--

INSERT INTO `ayuda` (`id`, `categoria_id`, `descripcion`, `foto`, `correo`, `estatus_id`, `fecha`) VALUES
(1, 2, 'el registro de usuarios de la pagina no funciona', 'registronofunciona.png', 'gomenasayamor@gmail.com', 1, '2022-01-20'),
(2, 2, 'el registro de usuarios dejo de funcionar repentinamente, soluciónenlo por favor', 'registronofunciona.png', 'nicole@gmail.com', 3, '2022-01-20'),
(3, 2, 'el registro de usuarios dejo de funcionar, cuando lo solucionaran.', 'registronofunciona.png', 'karen@gmail.com', 2, '2022-01-20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE `categoria` (
  `id` int(2) NOT NULL,
  `nombre_categoria` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`id`, `nombre_categoria`) VALUES
(1, 'Acceso a la cuenta'),
(2, 'Error o problema tecnico'),
(3, 'La cuenta ha sido cancelada'),
(4, 'Opiniones o comentarios'),
(5, 'Otros motivos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_solicitudes`
--

CREATE TABLE `detalle_solicitudes` (
  `id` int(11) NOT NULL,
  `solicitud_id` int(10) NOT NULL,
  `mascota_id` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `estatus_solicitud_id` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `detalle_solicitudes`
--

INSERT INTO `detalle_solicitudes` (`id`, `solicitud_id`, `mascota_id`, `cantidad`, `estatus_solicitud_id`) VALUES
(1, 1, 20, 1, 3),
(2, 2, 10, 1, 1),
(3, 2, 16, 1, 1),
(4, 3, 2, 1, 1),
(5, 3, 1, 1, 1),
(6, 4, 4, 1, 2),
(7, 4, 7, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `especies`
--

CREATE TABLE `especies` (
  `id` int(20) NOT NULL,
  `nombre_e` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `especies`
--

INSERT INTO `especies` (`id`, `nombre_e`) VALUES
(1, 'Perro'),
(2, 'Gato'),
(3, 'Hámster'),
(4, 'Pájaro'),
(5, 'Pez'),
(6, 'Conejo'),
(7, 'Tortuga'),
(8, 'Serpiente'),
(9, 'Iguana'),
(10, 'dragón barbudo'),
(11, 'Hurón'),
(12, 'Cobaya'),
(13, 'Ratón'),
(14, 'Liebre');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estatus_actual`
--

CREATE TABLE `estatus_actual` (
  `id` int(1) NOT NULL,
  `nombre_actual` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `estatus_actual`
--

INSERT INTO `estatus_actual` (`id`, `nombre_actual`) VALUES
(1, 'ACTIVA'),
(2, 'DESACTIVA'),
(3, 'SUSPENDIDA');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estatus_ayuda`
--

CREATE TABLE `estatus_ayuda` (
  `id` int(11) NOT NULL,
  `nombre_ayuda` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `estatus_ayuda`
--

INSERT INTO `estatus_ayuda` (`id`, `nombre_ayuda`) VALUES
(1, 'En espera'),
(2, 'Procesando'),
(3, 'Resuelto');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estatus_mascotas`
--

CREATE TABLE `estatus_mascotas` (
  `id_estatus` int(10) NOT NULL,
  `nombre_s` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `estatus_mascotas`
--

INSERT INTO `estatus_mascotas` (`id_estatus`, `nombre_s`) VALUES
(1, 'En Espera'),
(2, 'En Adopcion'),
(3, 'Adoptado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estatus_solicitud`
--

CREATE TABLE `estatus_solicitud` (
  `id` int(1) NOT NULL,
  `nombre` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `estatus_solicitud`
--

INSERT INTO `estatus_solicitud` (`id`, `nombre`) VALUES
(1, 'ACEPTADA'),
(2, 'PROCESANDO'),
(3, 'RECHAZADA');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mascotas`
--

CREATE TABLE `mascotas` (
  `id` int(11) NOT NULL,
  `especie_id` varchar(20) NOT NULL,
  `raza` varchar(100) NOT NULL,
  `nombre_m` varchar(100) NOT NULL,
  `sexo` varchar(20) NOT NULL,
  `color` varchar(20) NOT NULL,
  `edad` varchar(20) NOT NULL,
  `estatus_id` varchar(30) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `fecha` date DEFAULT NULL,
  `foto` varchar(100) NOT NULL,
  `telefono_dueno_ant` varchar(15) NOT NULL,
  `nombre_dueno_ant` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `mascotas`
--

INSERT INTO `mascotas` (`id`, `especie_id`, `raza`, `nombre_m`, `sexo`, `color`, `edad`, `estatus_id`, `descripcion`, `fecha`, `foto`, `telefono_dueno_ant`, `nombre_dueno_ant`) VALUES
(1, '1', 'Criollo', 'luna', 'Hembra', 'Negro', '2 Anos', '3', 'Me llamo luna fui encontrada golpeanda, ya me llevaron al veterinario y estoy bien ya me desparasitaron solo faltan mis vacunas, soy talla mediana soy muy tranquila y obediente te gustaria cambiarme ', '2021-12-09', 'luna.jpg', 'Sin Contacto', 'Sin Contacto'),
(2, '1', 'Schnauzer', 'Pluto', 'Macho', 'Cafe-Gris', '7 meses', '3', 'Cachorro Schnauzer macho en adopción. Cuenta con todas sus vacunas, está desparasitado y esterilizado Pluto necesita un dueño que tenga mucho tiempo para él debido a que tiene mucha mucha energía.', '2021-12-09', 'pluto.jpg', 'Sin Contacto', 'Sin Contacto'),
(3, '1', 'Criollo', 'Solo Vino', 'Macho', 'Cafe-Blanco', '2 años', '2', 'Soy un luchador, me rescataron a punto de morir, pero tengo muchas ganas de vivir, dame la oportunidad de ser parte de una familia, soy muy buen perro, sociable y juguetón! Tengo entrenamiento básico', '2021-12-09', 'solovino.jpg', 'Sin Contacto', 'Sin Contacto'),
(4, '1', 'Criollo', 'Coffe', 'Macho', 'Cafe', '7 meses', '1', 'Hermoso peludito llamado Coffe de 7 meses busca una familia amorosa, responsable y comprometida.convive con niños y es super cariñoso.', '2021-12-09', 'coffe.jpg', 'Sin Contacto', 'Sin Contacto'),
(5, '1', 'Criollo', 'Peludin', 'Macho', 'Negro-Blanco', '5 meses', '2', 'Hermoso peludín busca una familia amorosa, responsable y comprometida.', '2021-12-09', 'peludin.jpg', 'Sin Contacto', 'Sin Contacto'),
(6, '1', 'Alaskan Malamute', 'Matute', 'Hembra', 'Blanco', '4 años', '2', ' Adopción responsable. Alaskan Malamute tiene 4 años. Se pide esterilización. Identificación Oficial y firma de contrato de adopción. Y que envíen fotos de ella cada mes para darle seguimiento.', '2021-12-09', 'matute.jpg', 'Sin Contacto', 'Sin Contacto'),
(7, '2', 'Criollo', 'Lucifer', 'Macho', 'Negro', '2 años aprox', '1', 'Tiene aproximadamente dos años, es tranquilo, le gusta un poco los mimos y ya esta esterilizado. algunas veces se comporta extraño pero con agua bendita se le pasa', '2021-12-09', 'lucifer.jpg', 'Sin Contacto', 'Sin Contacto'),
(8, '1', 'Criollo', 'Benny', 'Macho', 'Cafe-Negro', 'aprox 6 meses', '2', 'talla grande suponemos\r\n✨esterilizado\r\n✨muy entendido y sigue aprendiendo\r\n✨convive con gatos y perros.\r\n\r\nEste bebé lo fueron a tirar con heridas a un basurero ????', '2021-12-09', 'Benny.jpg', '55 71 482114', 'Aurora'),
(9, '1', 'Criollo', 'Leía', 'Hembra', 'Negro', '2 años aprox', '2', 'talla grande\r\n✨esterilizada\r\n\r\nEsta pequeña fue maltratada con golpes y amarrada aún así es súper cariñosa y educada convive con otros perros y gatos', '2021-12-09', 'leila.jpg', '55 71 482114', 'Aurora'),
(10, '12', 'Criollo', 'Timoteo', 'Macho', 'Cafe-Negro', 'aproximada 2 a 3 año', '3', 'Lic. Timmy Bertho, ha sido muy valiente en su recuperación y ahora está Graduado con honores (Bueno, bueno hizo trampa en la práctica de tortillas calientitas) ????', '2022-01-17', 'Timoteo.jpg', 'Facebook @momim', 'Sin Contacto'),
(11, '12', 'Criollo', 'Valentina', 'Macho', 'Cafe', 'Sin Especificar', '2', 'Estoy en busca de un hogar seré talla ch a mediana no creceré tanto pero tampoco seré tan pequeña unos perros atacaron a mis hermanos y ami fui la única que sobreviví tenía mucha sarna y mi ojito esta', '2022-01-17', 'Valentina.jpg', 'facebook.com/di', 'Diana'),
(12, '12', 'Criollo', 'Bella', 'Macho', 'Negro-Blanco', '2 meses 1/2 de edad', '2', 'Energía alta, activa\r\nDemasiado juguetona\r\n( Le encantan los juguetes y jugar con perros de todos tamaños )\r\n\r\n???? Requiere de varios paseos al día ( terminando su cuadro de vacunación ) espacios par', '2022-01-17', 'Bella.jpg', '5518936288', 'Irma Hernández'),
(13, '12', 'Criollo', 'Micaelita', 'Macho', 'Cafe-Negro', 'Sin Especificar', '2', 'Hola, mi nombre es Micaelita. ✨????\r\nSoy un perrita mestiza, mi mamá lamentablemente no fue esterilizada y yo terminé en la calle. ????\r\n\r\nFui al veterinario, dónde ya me revisaron, me dijeron que est', '2022-01-17', 'Micaelita..jpg', '5549498466', 'Sin Contacto'),
(14, '12', 'cruza entre golden y cocker', 'Sin Nombre', 'Macho', 'Cafe', 'Sin Especificar', '2', 'Esta hermosa perrita cruza entre golden y cocker, está en adopción, es super cariñosa y busca una familia', '2022-01-17', 'sin nombre.jpg', '5530453813', 'Sin Contacto'),
(15, '12', 'Criollo', 'Sin Nombre', 'Macho', 'Negro', '2 meses', '2', '✨Tranquilo y muy limpio\r\n✨Desparasitado\r\n\r\nA este pequeñín lo encontraron en un panteón donde un niño que los alimentaba con lo que pudiera, lagartijas chapulines, insectos ya que a él no lo dejaban t', '2022-01-17', '261220026_2023599044477821_11392.jpg', '5529644526', 'Ari Rocha'),
(16, '12', 'Criollo', 'Vaca', 'Macho', 'Negro-Blanco', 'Sin Especificar', '3', 'tenía hogar pero al cambiarse de domicilio ya no me llevaron, una personas muy lindas me llevaron a esterilizar ya que ya estaba en celo, por unos días me dieron hogar temporal pero ahora me quedo en ', '2022-01-17', 'vaca.jpg', 'facebook.com/du', 'Sin Especificar'),
(17, '12', 'Criollo', 'Arya', 'Macho', 'Negro-Blanco', 'Sin Especificar', '2', 'está en busca de una familia RESPONSABLE que la ame, la respete y la proteja toda su vida... sin que la dejen plantada (otra vez). ????\r\nTiene dos meses y medio, será talla mediana. Es muy inteligente', '2022-01-17', 'Arya.jpg', 'facebook.com/pr', 'Sin Especificar'),
(18, '12', 'Sin Especificar', 'Ivan', 'Macho', 'Cafe', '4 meses', '2', 'Tiene 4 meses (es un bebe ????), lo tenían en muy malas condiciones, pero ahora ya está listo para irse a un hogar ???? en donde lo quieran ❤️ y lo traten bien. ????\r\nMayores de edad. ????\r\nFamilia re', '2022-01-17', 'ivan.jpg', '@Vero Ortuño', 'Sin Especificar'),
(19, '12', 'Sin Especificar', 'Sin Nombre', 'Macho', 'Negro-Blanco', 'Sin Especificar', '2', 'Espero a alguien le interese esta perrita la acaban de rescatar y se encuentra en tlalpan\r\nLa abandonaron', '2022-01-17', '258339023_2021238944713831_12973.jpg', '5549450344', 'Sin Especificar'),
(20, '12', 'Criollo', 'Algodón', 'Macho', 'Blanco', 'Sin Especificar', '2', 'Soy un perrito rescatado, cuando me encontraron estaba husmeando entre unas bolsas de basura y tomando agua muy rica de un charco. ????\r\nFui al veterinario, dónde me trataron, me bañaron y desparasita', '2022-01-18', 'agodon.jpg', 'facebook.com/ds', 'Sin Especificar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `postulados`
--

CREATE TABLE `postulados` (
  `id` int(11) NOT NULL,
  `nombre_usuario` varchar(100) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `telefono` int(10) NOT NULL,
  `direccion` varchar(200) NOT NULL,
  `motivo` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `postulados`
--

INSERT INTO `postulados` (`id`, `nombre_usuario`, `correo`, `telefono`, `direccion`, `motivo`) VALUES
(1, 'Hector Dario Vazquez Gonzalez', 'gomenasayamor@gmail.com', 12345678, 'conocido', 'hola'),
(2, 'karen cruz', 'karen@gmail.com', 12345678, 'conocido', ''),
(3, 'karen cruz', 'karen@gmail.com', 12345678, 'conocido', 'Esto es una prueba del servidor'),
(4, 'karen cruz', 'karen@gmail.com', 1234567890, 'conocido', 'esto es una prueba.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes`
--

CREATE TABLE `solicitudes` (
  `id` int(10) NOT NULL,
  `postulado_id` int(11) NOT NULL,
  `total` int(1) NOT NULL,
  `fecha` date NOT NULL,
  `estatus_solicitud_id` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `solicitudes`
--

INSERT INTO `solicitudes` (`id`, `postulado_id`, `total`, `fecha`, `estatus_solicitud_id`) VALUES
(1, 1, 1, '2021-12-10', 3),
(2, 2, 2, '2021-12-11', 1),
(3, 3, 2, '2022-01-14', 1),
(4, 4, 2, '2022-01-20', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre_usuario` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `sobrenombre` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(320) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` int(10) NOT NULL,
  `direccion` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `clave` varchar(500) COLLATE utf8_spanish_ci NOT NULL,
  `estatus_actual_id` int(1) NOT NULL,
  `administrador_id` int(1) NOT NULL,
  `fecha` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre_usuario`, `sobrenombre`, `correo`, `telefono`, `direccion`, `clave`, `estatus_actual_id`, `administrador_id`, `fecha`) VALUES
(1, 'Hector Dario Vazquez Gonzalez', 'Itzal Maltzurra', 'gomenasayamor@gmail.com', 1234567889, 'conocido', '1af247e88db0afe0fa886fc2b943da6c0160fb6f8931f08d4338ad2e00de79d3b6707f6c8ff9f9f9d2224926cc8e0f2c3ab83bcbb657b987189dbf00470b4d48', 1, 12, '2022-01-20 18:57:46'),
(2, 'karen cruz', 'Ana', 'karen@gmail.com', 1234567890, 'conocido', '1af247e88db0afe0fa886fc2b943da6c0160fb6f8931f08d4338ad2e00de79d3b6707f6c8ff9f9f9d2224926cc8e0f2c3ab83bcbb657b987189dbf00470b4d48', 2, 0, NULL),
(3, 'Nicole Matute', 'Nicole', 'nicole@gmail.com', 1234567890, 'Honduras, valle de los ángeles, cerca de la cafetería local.', '1af247e88db0afe0fa886fc2b943da6c0160fb6f8931f08d4338ad2e00de79d3b6707f6c8ff9f9f9d2224926cc8e0f2c3ab83bcbb657b987189dbf00470b4d48', 1, 0, '2022-01-20 16:17:36'),
(4, 'Vviana Romero', 'vivi', 'viviana@gmail.com', 987654321, 'san José del rincón', '1af247e88db0afe0fa886fc2b943da6c0160fb6f8931f08d4338ad2e00de79d3b6707f6c8ff9f9f9d2224926cc8e0f2c3ab83bcbb657b987189dbf00470b4d48', 1, 0, '2022-02-03 01:42:37');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administrador`
--
ALTER TABLE `administrador`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `ayuda`
--
ALTER TABLE `ayuda`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `detalle_solicitudes`
--
ALTER TABLE `detalle_solicitudes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `solicitud_id` (`solicitud_id`);

--
-- Indices de la tabla `especies`
--
ALTER TABLE `especies`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estatus_actual`
--
ALTER TABLE `estatus_actual`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estatus_ayuda`
--
ALTER TABLE `estatus_ayuda`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estatus_mascotas`
--
ALTER TABLE `estatus_mascotas`
  ADD PRIMARY KEY (`id_estatus`);

--
-- Indices de la tabla `estatus_solicitud`
--
ALTER TABLE `estatus_solicitud`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mascotas`
--
ALTER TABLE `mascotas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `postulados`
--
ALTER TABLE `postulados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `administrador`
--
ALTER TABLE `administrador`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `ayuda`
--
ALTER TABLE `ayuda`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `detalle_solicitudes`
--
ALTER TABLE `detalle_solicitudes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `especies`
--
ALTER TABLE `especies`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `estatus_actual`
--
ALTER TABLE `estatus_actual`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `estatus_ayuda`
--
ALTER TABLE `estatus_ayuda`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `estatus_mascotas`
--
ALTER TABLE `estatus_mascotas`
  MODIFY `id_estatus` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `estatus_solicitud`
--
ALTER TABLE `estatus_solicitud`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `mascotas`
--
ALTER TABLE `mascotas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `postulados`
--
ALTER TABLE `postulados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
