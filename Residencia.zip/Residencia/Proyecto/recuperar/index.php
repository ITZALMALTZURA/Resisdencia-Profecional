<?php session_start();
require '../conexion.php';
if (isset($_SESSION['usuario'])) {
    header('location: panel/index.php');
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $nombre_usuario = $_POST['nombre_usuario'];
    $sobrenombre = $_POST['sobrenombre'];
    $correo = $_POST['correo'];
    $telefono = $_POST['telefono'];

    $error = '';

    if (empty($nombre_usuario) or empty($sobrenombre) or empty($correo) or empty($telefono)) {

        $error .= '<i style="color: red;">Favor de rellenar todos los campos</i>';
    }

    $statement = $conexion->prepare(
        '
        SELECT * FROM usuarios WHERE correo = :correo AND telefono = :telefono AND nombre_usuario = :nombre_usuario AND sobrenombre = :sobrenombre'
    );

    $statement->execute(array(
        ':correo' => $correo,
        ':telefono' => $telefono,
        ':nombre_usuario' => $nombre_usuario,
        ':sobrenombre' => $sobrenombre
    ));

    $resultado = $statement->fetch();

    if ($resultado !== false) {
        $_SESSION['recuperar'] = $correo;
        header('location: actualizar_clave.php');
    } else {
        $error = '';
        $error .= '<i style="color: red;">Favor de ingresar los datos correctos</i>';
    }
}
require 'recuperar.php';
