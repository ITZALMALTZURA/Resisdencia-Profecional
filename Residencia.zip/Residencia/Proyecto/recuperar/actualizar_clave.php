<?php session_start();
require_once '../conexion.php';
if (isset($_SESSION['recuperar'])) {
    $email_sesion = $_SESSION['recuperar'];
    $query_sesion = $conexion->prepare("SELECT * FROM usuarios WHERE correo ='$email_sesion'");
    $query_sesion->execute();

    $sesion_usuarios = $query_sesion->fetchAll(PDO::FETCH_ASSOC);
    foreach ($sesion_usuarios as $sesion_usuario) {
        $correo = $sesion_usuario['correo'];
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $clave = $_POST['clave'];
        $clave2 = $_POST['clave2'];

        $clave = hash('sha512', $clave);
        $clave2 = hash('sha512', $clave2);

        $error = '';
        if (empty($clave) or empty($clave2)) {

            $error .= '<i style="color: red;">Favor de rellenar todos los campos</i>';
        }




        if ($clave != $clave2) {
            $error .= '<i style="color: red;"> Las contraseñas no son iguales</i>';
        }



        if ($error == '') {

            $statement = $conexion->prepare("UPDATE `usuarios` SET `clave`=:clave WHERE `correo`= :correo ");
            $statement->execute(array(
                ':clave' => $clave,
                ':correo' => $correo
            ));

            $error .= '<i style="color: green;">Usuario actualizado exitosamente</i>';
        }
    }
} else {
    header('Location: login.php');
    die();
}

require 'cambiar_clave.php';
