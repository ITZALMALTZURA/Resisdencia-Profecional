<?php
require_once '../conexion.php';

if (isset($_SESSION['recuperar'])) {
  $email_sesion = $_SESSION['recuperar'];
  $query_sesion = $conexion->prepare("SELECT * FROM usuarios WHERE correo ='$email_sesion'");
  $query_sesion->execute();
  $sesion_usuarios = $query_sesion->fetchAll(PDO::FETCH_ASSOC);
  foreach ($sesion_usuarios as $sesion_usuario) {
    $id = $sesion_usuario['id'];
    $nombre_usuario = $sesion_usuario['nombre_usuario'];
    $sobrenombre = $sesion_usuario['sobrenombre'];
    $correo = $sesion_usuario['correo'];
    $telefono = $sesion_usuario['telefono'];
    $direccion = $sesion_usuario['direccion'];
  }

?>
  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fundación Albornoz Jiménez A.C.</title>

    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/estilos.css">
    <link rel="shorcut icon" type="image/x-icon" href="../assets/imagenes/Fundacion.ico">
  </head>

  <body>

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav pull-right">

            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $sobrenombre ?><span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="../Cerrar_session.php">Salir</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
      <!--/.nav-collapse -->
    </nav>

    <div class="container" id="main">
      <div class="main-form">
        <div class="row">
          <div class="col-md-12">
            <fieldset>
              <legend>Puede actualizar su contraseña</legend>
              <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" class="mb-5">

                <div class="form-group">
                  <label for="clave">Nueva Contraseña</label>
                  <input type="text" minlength="4" maxlength="20" class="form-control" placeholder="ingrese su nueva contraseña" name="clave" id="clave" pattern="[^[a-zA-Z0-9.!#$%&*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$]{4,20}" title="Minimo 4 caracteres Maximo 20" required>
                </div>
                <div class="form-group">
                  <label for="clave2">Confirme su nueva Contraseña</label>
                  <input type="text" minlength="4" maxlength="20" class="form-control" placeholder="ingrese su nueva contraseña" name="clave2" id="clave2" pattern="[^[a-zA-Z0-9.!#$%&*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$]{4,20}" title="Minimo 4 caracteres Maximo 20" required>
                </div>
                <?php if (!empty($error)) : ?>
                  <div class="mensaje">
                    <?php echo $error; ?>
                  </div>
                <?php endif; ?>
                <div class="row">
                  <div class="d-grid gap-2 d-md-flex justify-content-md-end ">
                    <button type="submit" class="btn btn-info me-md-2">Actualizar</button>
                  </div>
                </div>
              </form>
            </fieldset>
          </div>
        </div>
      </div>
    </div> <!-- /container -->

  </body>
  <!--JavaScript -->
  <script src="../assets/js/jquery.min.js"></script>
  <script src="../assets/js/bootstrap.min.js"></script>

  </html>

<?php
} else {
  header('Location: login.php'); 
  die();
}
?>