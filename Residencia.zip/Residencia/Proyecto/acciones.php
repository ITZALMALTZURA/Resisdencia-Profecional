<?php
require 'vendor/autoload.php';

$ayuda = new fundacion\Ayuda;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($_POST['accion'] === 'Registrar') {

        if (empty($_POST['categoria_id']))
            exit('Seleccionar una categoria válida');

        if (!is_numeric($_POST['categoria_id']))
            exit('Selecciona una categoria');

        if (empty($_POST['descripcion']))
            exit('Completar campo descripcion');

        if (empty($_POST['correo']))
            exit('ingrese un correo valido');

        $_params = array(
            'categoria_id' => $_POST['categoria_id'],
            'descripcion' => $_POST['descripcion'],
            'correo' => $_POST['correo'],
            'foto' => subirFoto(),
            'fecha' => date('Y-m-d')

        );

        $rpt = $ayuda->registrar($_params);

        if ($rpt) {
?>
            <!DOCTYPE html>
            <html lang="en">

            <head>
                <meta charset="utf-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
                <meta name="description" content="">
                <meta name="author" content="">

                <title>Fundación Albornoz Jiménez A.C.</title>

                <!--  CSS -->
                <link rel="stylesheet" href="assets/css/bootstrap.min.css">
                <link rel="stylesheet" href="assets/css/estilos.css">
                <link rel="shorcut icon" type="image/x-icon" href="assets/imagenes/Fundacion.ico">
            </head>

            <body>


                <div class="container" id="main">
                    <div class="row">
                        <div style="background-color:#E0F8F7;" class="jumbotron">
                            <p align="justify">¡Gracias por informarnos! </p><br>
                            <p align="justify">Buscaremos la forma de solucionarlo.</p>
                            <p>
                                <a href="index.php">Regresar</a>
                            </p>
                        </div>
                    </div>
                </div> <!-- /container -->
                <!--  JavaScript-->
                <script src="assets/js/jquery.min.js"></script>
                <script src="assets/js/bootstrap.min.js"></script>
                <script type='text/javascript'>
                    $(function() {
                        $(document).bind("contextmenu", function(e) {
                            return false;
                        });
                    });
                </script>
            </body>

            </html>
<?php
            header('Refresh: 5; URL= index.php');
            die();
        } else {
            print 'Error al registrar una mascota';
        }
    }
}




function subirFoto()
{

    $carpeta = __DIR__ . '/upload/';

    $archivo = $carpeta . $_FILES['foto']['name'];

    move_uploaded_file($_FILES['foto']['tmp_name'], $archivo);

    return $_FILES['foto']['name'];
}
