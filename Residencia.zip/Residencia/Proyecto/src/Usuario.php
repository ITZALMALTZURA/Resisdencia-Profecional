<?php

namespace fundacion;

class Usuario
{

    private $config;
    private $cn = null;

    public function __construct()
    {

        $this->config = parse_ini_file(__DIR__ . '/../config.ini');

        $this->cn = new \PDO($this->config['dns'], $this->config['usuario'], $this->config['clave'], array(
            \PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'
        ));
    }



    public function activar($id)
    {

        $sql = "UPDATE usuarios  
        SET estatus_actual_id = 1
        WHERE estatus_actual_id != 1 AND id = :id";


        $resultado = $this->cn->prepare($sql);
        $_array = array(
            ':id' => $id
        );

        if ($resultado->execute($_array))
            return  $resultado->fetch();

        return false;
    }
    public function suspender($id)
    {

        $sql = "UPDATE usuarios u, estatus_actual ea 
        SET u.estatus_actual_id = 3 
        WHERE u.estatus_actual_id != 3 AND u.id = :id";

        $resultado = $this->cn->prepare($sql);
        $_array = array(
            ':id' => $id
        );

        if ($resultado->execute($_array))
            return  $resultado->fetch();

        return false;
    }

    public function mostrar()
    {

        $sql = "SELECT u.id, u.nombre_usuario, u.sobrenombre, u.correo, u.telefono, u.direccion, nombre_actual
        FROM usuarios u
        INNER JOIN estatus_actual ea ON u.estatus_actual_id = ea.id
        ORDER BY u.id DESC
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return $resultado->fetchAll();

        return false;
    }
    public function mostrarActualizadas()
    {

        $sql = "SELECT u.id, u.nombre_usuario, u.sobrenombre, u.correo, u.telefono, u.direccion, u.fecha, ad.nombre_usuario as admin_nombre, ad.correo as admin_correo
        FROM usuarios u
        INNER JOIN administrador ad ON u.administrador_id = ad.id
        ORDER BY u.id DESC
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return $resultado->fetchAll();

        return false;
    }
    public function mostrarActivas()
    {
        $sql = "SELECT u.id, nombre_usuario, sobrenombre, correo, telefono, direccion, nombre_actual 
        FROM usuarios u
        INNER JOIN estatus_actual ea ON u.estatus_actual_id = ea.id
        WHERE ea.id = 1 
        ORDER BY u.id DESC
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return $resultado->fetchAll();

        return false;
    }

    public function mostrarDesactivas()
    {
        $sql = "SELECT u.id, nombre_usuario, sobrenombre, correo, telefono, direccion, nombre_actual 
        FROM usuarios u
        INNER JOIN estatus_actual ea ON u.estatus_actual_id = ea.id
        WHERE ea.id = 2 
        ORDER BY u.id DESC
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return $resultado->fetchAll();

        return false;
    }

    public function mostrarSuspendidas()
    {
        $sql = "SELECT u.id, nombre_usuario, sobrenombre, correo, telefono, direccion, nombre_actual 
        FROM usuarios u
        INNER JOIN estatus_actual ea ON u.estatus_actual_id = ea.id
        WHERE ea.id = 3 
        ORDER BY u.id DESC
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return $resultado->fetchAll();

        return false;
    }

    public function mostrarPorId($id)
    {
        $sql = "SELECT u.id, nombre_usuario, sobrenombre, correo, telefono, direccion
        FROM usuarios u
        WHERE u.id = :id 
        ";

        $resultado = $this->cn->prepare($sql);
        $_array = array(
            ":id" =>  $id
        );

        if ($resultado->execute($_array))
            return $resultado->fetch();

        return false;
    }

    public function actualizarUsuario($_params)
    {
        $sql = "UPDATE `usuarios` SET `nombre_usuario`=:nombre_usuario,`correo`=:correo,`telefono`=:telefono,`direccion`=:direccion,`administrador_id`=:administrador_id,`fecha`=:fecha WHERE `id`=:id";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":nombre_usuario" => $_params['nombre_usuario'],
            ":correo" => $_params['correo'],
            ":telefono" => $_params['telefono'],
            ":direccion" => $_params['direccion'],
            ":id" => $_params['id'],
            ":administrador_id" => $_params['administrador_id'],
            ":fecha" => $_params['fecha']
        );

        if ($resultado->execute($_array))
            return true;

        return false;
    }

    

    public function graficageneral()
    {
        $sql = "SELECT * FROM usuarios
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            $resultados = $resultado->fetchAll();
        $validos = count($resultados);
        return $validos;
    }

    public function graficaActivas()
    {
        $sql = "SELECT * FROM usuarios
        WHERE estatus_actual_id = 1  
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            $resultados = $resultado->fetchAll();
        $validos = count($resultados);
        return $validos;
    }

    public function graficaDesactivas()
    {
        $sql = "SELECT * FROM usuarios
        WHERE estatus_actual_id = 2  
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            $resultados = $resultado->fetchAll();
        $validos = count($resultados);
        return $validos;
    }

    public function graficaSuspendidas()
    {
        $sql = "SELECT * FROM usuarios
        WHERE estatus_actual_id = 3  
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            $resultados = $resultado->fetchAll();
        $validos = count($resultados);
        return $validos;
    }

    public function graficaActualizadas()
    {
        $sql = "SELECT u.id, u.administrador_id
        FROM usuarios u
        INNER JOIN administrador ad ON u.administrador_id = ad.id";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            $resultados = $resultado->fetchAll();
        $validos = count($resultados);
        return $validos;
    }
}
