<?php

namespace fundacion;

class Solicitud
{

    private $config;
    private $cn = null;

    public function __construct()
    {

        $this->config = parse_ini_file(__DIR__ . '/../config.ini');

        $this->cn = new \PDO($this->config['dns'], $this->config['usuario'], $this->config['clave'], array(
            \PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'
        ));
    }

    public function registrar($_params)
    {
        $sql = "INSERT INTO `solicitudes`(`postulado_id`, `total`, `fecha`, `estatus_solicitud_id`) 
        VALUES (:postulado_id,:total,:fecha, '2')";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":postulado_id" => $_params['postulado_id'],
            ":total" => $_params['total'],
            ":fecha" => $_params['fecha'],

        );

        if ($resultado->execute($_array))
            return $this->cn->lastInsertId();

        return false;
    }

    public function registrarDetalle($_params)
    {
        $sql = "INSERT INTO `detalle_solicitudes`(`solicitud_id`, `mascota_id`, `cantidad`, `estatus_solicitud_id`) 
        VALUES (:solicitud_id,:mascota_id,:cantidad,'2')";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":solicitud_id" => $_params['solicitud_id'],
            ":mascota_id" => $_params['mascota_id'],
            ":cantidad" => $_params['cantidad'],
        );

        if ($resultado->execute($_array))
            return true;

        return false;
    }

    public function actualizarEstatus($_params)
    {
        $sql = "UPDATE `mascotas` SET `estatus_id`= 1 WHERE `id`=:id";
        $resultado = $this->cn->prepare($sql);
        $_array = array(

            ":id" =>  $_params['id']
        );
        if ($resultado->execute($_array))
            return  true;

        return false;
    }
    
    public function mostrar()
    {
        $sql = "SELECT s.id, nombre_usuario, correo, total, fecha FROM solicitudes s 
        INNER JOIN postulados p ON s.postulado_id = p.id ORDER BY s.id DESC";

        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return  $resultado->fetchAll();

        return false;
    }

    
    public function mostrarUltimos()
    {
        $sql = "SELECT s.id, nombre_usuario, correo, total, fecha FROM solicitudes s 
        INNER JOIN postulados p ON s.postulado_id = p.id ORDER BY s.id DESC LIMIT 10";

        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return  $resultado->fetchAll();

        return false;
    }

    public function mostrarPorId($id)
    {
        $sql = "SELECT s.id, nombre_usuario, correo, telefono, direccion,  total, motivo, fecha FROM solicitudes s 
        INNER JOIN postulados p ON s.postulado_id = p.id WHERE s.id = :id";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ':id' => $id
        );

        if ($resultado->execute($_array))
            return  $resultado->fetch();

        return false;
    }
   


    public function mostrarDetallePorIdSolicitud($id)
    {
        $sql = "SELECT 
                ds.id,
                ms.nombre_m,
                ms.sexo,
                ms.edad,
                ms.raza,
                ds.cantidad,
                ms.foto
                FROM detalle_solicitudes ds
                INNER JOIN mascotas ms ON ms.id= ds.mascota_id
                WHERE ds.solicitud_id = :id ORDER BY ds.id DESC";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ':id' => $id
        );

        if ($resultado->execute($_array))
            return  $resultado->fetchAll();

        return false;
    }
    public function aprobar($id)

    {
        $sql2 = "SELECT s.id FROM solicitudes s WHERE s.id = :id";
        $sql = "UPDATE detalle_solicitudes ds, solicitudes s , mascotas m, usuarios u, postulados p SET ds.estatus_solicitud_id = 1, s.estatus_solicitud_id = 1, m.estatus_id = 3, u.estatus_actual_id = 1 
        WHERE ds.solicitud_id = :id AND s.id=ds.solicitud_id AND ds.mascota_id = m.id AND p.correo = u.correo";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ':id' => $id
        );

        if ($resultado->execute($_array))
           
            return  $resultado->fetch();
            

        return false;



    }
    public function denegar($id)

    {
        $sql2 = "SELECT s.id FROM solicitudes s WHERE s.id = :id";
        $sql = "UPDATE detalle_solicitudes ds, solicitudes s , mascotas m, usuarios u, postulados p SET ds.estatus_solicitud_id = 3, s.estatus_solicitud_id = 3, m.estatus_id = 2, u.estatus_actual_id = 1 
                WHERE ds.solicitud_id = :id AND s.id=ds.solicitud_id AND ds.mascota_id = m.id AND p.correo = u.correo";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ':id' => $id
        );

        if ($resultado->execute($_array))
           
            header('../panel/solicitud/index.php');
            return  $resultado->fetch();
            

        return false;

    }

    public function mostrarEspera()

    {
        
        $sql = "SELECT s.id, p.nombre_usuario, total, fecha, estatus_solicitud_id FROM solicitudes s, postulados p 
        WHERE s.postulado_id = p.id AND estatus_solicitud_id = '2' ORDER BY s.id ASC";



        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return  $resultado->fetchAll();

        return false;
    }
 
}


