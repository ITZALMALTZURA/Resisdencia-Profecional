<?php

namespace fundacion;

class Ayuda
{

    private $config;
    private $cn = null;

    public function __construct()
    {

        $this->config = parse_ini_file(__DIR__ . '/../config.ini');

        $this->cn = new \PDO($this->config['dns'], $this->config['usuario'], $this->config['clave'], array(
            \PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'
        ));
    }

    public function registrar($_params)
    {
        $sql = "INSERT INTO `ayuda`(`categoria_id`,`descripcion`, `foto`, `correo`,`estatus_id`,`fecha`) 
        VALUES (:categoria_id,:descripcion,:foto,:correo,1,:fecha)";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":categoria_id" => $_params['categoria_id'],
            ":descripcion" => $_params['descripcion'],
            ":foto" => $_params['foto'],
            ":correo" => $_params['correo'],
            ":fecha" => $_params['fecha']
        );

        if ($resultado->execute($_array))
            return true;

        return false;
    }


    public function procesar($id)
    {

        $sql = "UPDATE ayuda h SET h.estatus_id = 2
        WHERE h.id = :id AND h.estatus_id = 1";

        $resultado = $this->cn->prepare($sql);
        $_array = array(
            ':id' => $id
        );

        if ($resultado->execute($_array))
            return  $resultado->fetch();

        return false;
    }
    public function resolver($id)
    {

        $sql = "UPDATE ayuda h SET h.estatus_id = 3
        WHERE h.id = :id AND h.estatus_id = 2";

        $resultado = $this->cn->prepare($sql);
        $_array = array(
            ':id' => $id
        );

        if ($resultado->execute($_array))
            return  $resultado->fetch();

        return false;
    }

    public function mostrar()
    {
        $sql = "SELECT h.id, nombre_categoria, descripcion, correo, nombre_ayuda, foto, fecha FROM ayuda h

        INNER JOIN categoria c ON h.categoria_id = c.id 
        INNER JOIN estatus_ayuda ea ON h.estatus_id = ea.id 
        ORDER BY h.id DESC
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return $resultado->fetchAll();

        return false;
    }

    public function mostrarPorId($id)
    {

        $sql = "SELECT h.id, nombre_categoria, descripcion, correo, nombre_ayuda, foto, fecha FROM ayuda h

        INNER JOIN categoria c ON h.categoria_id = c.id 
        INNER JOIN estatus_ayuda ea ON h.estatus_id = ea.id 
        WHERE h.id=:id ";

        $resultado = $this->cn->prepare($sql);
        $_array = array(
            ":id" =>  $id
        );

        if ($resultado->execute($_array))
            return $resultado->fetch();

        return false;
    }
    public function mostrarDetallePorIdAyuda($id)
    {
        $sql = "SELECT 
                h.id, 
                c.nombre_categoria, 
                h.descripcion, 
                h.correo, 
                ea.nombre_ayuda, 
                h.foto, 
                h.fecha
                FROM ayuda h
                INNER JOIN categoria c ON h.categoria_id = c.id 
                INNER JOIN estatus_ayuda ea ON h.estatus_id = ea.id 
                WHERE h.id=:id ";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ':id' => $id
        );

        if ($resultado->execute($_array))
            return  $resultado->fetchAll();

        return false;
    }

    public function mostrarprocesando()
    {
        $sql = "SELECT h.id, nombre_categoria, descripcion, correo, nombre_ayuda, foto, fecha 
        FROM ayuda h, categoria c, estatus_ayuda ea
        WHERE h.categoria_id = c.id 
        AND h.estatus_id = ea.id
        AND h.estatus_id = 2 
        ORDER BY h.id DESC
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return $resultado->fetchAll();

        return false;
    }

    public function mostrarresueltos()
    {
        $sql = "SELECT h.id, nombre_categoria, descripcion, correo, nombre_ayuda, foto, fecha 
        FROM ayuda h, categoria c, estatus_ayuda ea
        WHERE h.categoria_id = c.id 
        AND h.estatus_id = ea.id
        AND h.estatus_id = 3 
        ORDER BY h.id DESC
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return $resultado->fetchAll();

        return false;
    }
    public function graficageneral()
    {
        $sql = "SELECT * FROM ayuda
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            $resultados = $resultado->fetchAll();
        $validos = count($resultados);
        return $validos;
    }

    public function graficaenespera()
    {
        $sql = "SELECT * FROM ayuda
        WHERE estatus_id = 1  
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            $resultados = $resultado->fetchAll();
        $validos = count($resultados);
        return $validos;
    }

    public function graficaprocesando()
    {
        $sql = "SELECT * FROM ayuda
        WHERE estatus_id = 2  
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            $resultados = $resultado->fetchAll();
        $validos = count($resultados);
        return $validos;
    }

    public function graficaresueltos()
    {
        $sql = "SELECT * FROM ayuda
        WHERE estatus_id = 3  
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            $resultados = $resultado->fetchAll();
        $validos = count($resultados);
        return $validos;
    }

    public function graficaaccesoalacuenta()
    {
        $sql = "SELECT * FROM ayuda
        WHERE categoria_id = 1";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            $resultados = $resultado->fetchAll();
        $validos = count($resultados);
        return $validos;
    }

    public function graficaproblematecnico()
    {
        $sql = "SELECT * FROM ayuda
        WHERE categoria_id = 2  
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            $resultados = $resultado->fetchAll();
        $validos = count($resultados);
        return $validos;
    }

    public function graficacuentacancelada()
    {
        $sql = "SELECT * FROM ayuda
        WHERE categoria_id = 3  
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            $resultados = $resultado->fetchAll();
        $validos = count($resultados);
        return $validos;
    }

    public function graficaopiniones()
    {
        $sql = "SELECT * FROM ayuda
        WHERE categoria_id = 4  
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            $resultados = $resultado->fetchAll();
        $validos = count($resultados);
        return $validos;
    }

    public function graficaotrosmotivos()
    {
        $sql = "SELECT * FROM ayuda
        WHERE categoria_id = 5  
        ";
        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            $resultados = $resultado->fetchAll();
        $validos = count($resultados);
        return $validos;
    }
}
