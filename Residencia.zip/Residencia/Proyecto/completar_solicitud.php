<?php

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    require 'funciones.php';
    require 'vendor/autoload.php';

    if (isset($_SESSION['carrito']) && !empty($_SESSION['carrito'])) {

        $postulado = new fundacion\Postulado;

        $_params = array(
            'nombre_usuario' => $_POST['nombre_usuario'],
            'correo' => $_POST['correo'],
            'telefono' => $_POST['telefono'],
            'direccion' => $_POST['direccion'],
            'motivo' => $_POST['motivo']
        );

        $postulado_id = $postulado->registrar($_params);


        $solicitud = new fundacion\Solicitud;

        $_params = array(
            'postulado_id' => $postulado_id,
            'total' => calcularTotal(),
            'fecha' => date('Y-m-d')
        );

        $solicitud_id =  $solicitud->registrar($_params);

        foreach ($_SESSION['carrito'] as $indice => $value) {
            $_params = array(
                "solicitud_id" => $solicitud_id,
                "mascota_id" => $value['id'],
                "cantidad" => $value['cantidad'],
            );

            $solicitud->registrarDetalle($_params);
        }
        foreach ($_SESSION['carrito'] as $indice => $value) {
            $_params = array(
                "id" => $value['id']
            );

            $solicitud->actualizarEstatus($_params);
        }
        

        $_SESSION['carrito'] = array();

        header('Location: gracias.php');
    }
}
