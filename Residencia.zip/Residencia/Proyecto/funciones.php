<?php


function agregarMascota($resultado, $id, $cantidad = 1){
    $_SESSION['carrito'][$id] = array(
        'id' => $resultado['id'],
        'nombre_m' => $resultado['nombre_m'],
        'foto' => $resultado['foto'],
        'descripcion' => $resultado['descripcion'],
        'sexo' => $resultado['sexo'],
        'edad' => $resultado['edad'],
        'raza' => $resultado['raza'],
        'cantidad' => $cantidad
   );
}


function actualizarMascota($id,$cantidad = FALSE){

    if($cantidad)
        $_SESSION['carrito'][$id]['cantidad'] = $cantidad;
    else
        $_SESSION['carrito'][$id]['cantidad']=1;
}


function calcularTotal(){

    $total = 0;
    if(isset($_SESSION['carrito'])){
        foreach($_SESSION['carrito'] as $indice => $value){
            $total++;
        }
    }
    return $total;

}

function cantidadMascota(){
    $cantidad = 0;
    if(isset($_SESSION['carrito'])){
        foreach($_SESSION['carrito'] as $indice => $value){
           $cantidad++;
        }
    }
    
    return $cantidad;
}

