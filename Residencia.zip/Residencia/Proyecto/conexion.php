<?php

$conexion = new PDO('mysql:host=localhost;dbname=id18011743_fundacion', 'id18011743_root', ']vws++g?P3OT2Y]j');
?>