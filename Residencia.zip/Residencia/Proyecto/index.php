<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Fundación Albornoz Jiménez A.C.</title>

  <!-- CSS -->
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/estilos.css">
  <link rel="shorcut icon" type="image/x-icon" href="assets/imagenes/Fundacion.ico">
</head>

<!-- Fixed navbar -->
<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php">FAJ</a>
    </div>
    <div id="navbar" class="navbar-collapse collapse">
      <ul class="nav navbar-nav pull-right">
        <li class="active">
          <a href="index.php" class="btn">Acerca de</a>
        </li>
        <li>
          <a href="dashboard.php" class="btn">Mascotas</a>
        </li>
        <li>
          <a href="login.php" class="btn">Iniciar sesión</a>
        </li>
        <li>
          <a href="registro.php" class="btn">Registrarse</a>
        </li>
      </ul>
    </div>
    <!--/.nav-collapse -->
  </div>
</nav>

<body>

  <!--img-->
  <div class="container px-5 px-lg-5 mt-5" id="main">
    <div class="row gx-5 gx-lg-5 row-cols-2 justify-content-center">
      <div class="text-center">
        <img src="assets/imagenes/FundacionAJ.jpg" class="rounded mx-auto d-block img-thumbnail" alt="..."><br><br>
      </div>
      <!--cards-->
      <!-- Acerca de -->
      <div class="col 12 ">
        <div class="panel panel-default">
          <div class="panel-heading panel-info">
            <h3 class=" text-center ">Acerca de la Fundación Albornoz Jiménez A.C.</h3>
          </div>
          <div class="class= card h-100">
            <div class="card-body p-4 ">
              <p class="h4 container px-4 px-lg-5 mt-5" align="justify">
                La Fundación Albornoz Jiménez A.C. se encarga de ayudar a
                animales de la calle, a rescatistas independientes y asociaciones
                que lo necesiten. Mediante atención veterinaria con cualquier animal
                que esté en estado indefenso lo ideal es crear conciencia a través de
                la educación, actualmente en nuestro país no existe la educación para
                salvar vidas de seres sintientes.
              </p>
            </div>
          </div>
        </div>
      </div>
      <!-- Historia -->
      <div class="panel panel-default">
        <div class="panel-heading panel-info">
          <h3 class=" text-center ">Historia</h3>
        </div>
        <div class="class= card h-100">
          <div class="card-body p-4 ">
            <p class="h4 container px-4 px-lg-5 mt-5" align="justify">
              El 23 de agosto del 2018 se constituyó de manera formal la
              Fundación Albornoz Jiménez por la activista y presidenta de
              la misma Fundación: Anyel Carrillo de Albornoz Jiménez, quien
              es amante de los animales y ha vivido grandes experiencias y
              retos con veterinarios.
              <br><br>
              Actualmente,
              la Fundación Albornoz Jiménez tiene 15 casos al mes y 4 animales
              son dados en adopción, gracias a las estrategias se han logrado
              superar los objetivos planteados y ayudar y beneficiar a animales
              callejeros, teniendo un impacto social. Así mismo, se busca hacer
              una red nacional, así cualquier persona que encuentre un animal
              herido o en situación de calle, pueda llevar al ser sintiente a
              la clínica veterinaria más cercana y podamos brindarle la mejor
              atención que necesite.
            </p>
          </div>
        </div>
      </div>
      <!-- Mision -->
      <div class="panel panel-default">
        <div class="panel-heading panel-info">
          <h3 class=" text-center ">Misión</h3>
        </div>
        <div class="class= card h-100">
          <div class="card-body p-4 ">
            <p class="h4 container px-4 px-lg-5 mt-5" align="justify">
              Nuestra misión no solamente es ayudar a los animales, queremos
              crear conciencia a través de la educación, actualmente en nuestro
              país no existe la educación necesaria, no solamente queremos salvar
              vidas de seres sintientes, sino crear futuros y destinos de jóvenes
              que quieran estudiar una carrera, a través de una beca 100% y de validez oficial.
            </p>
          </div>
        </div>
      </div>
      <!-- Vision -->
      <div class="panel panel-default">
        <div class="panel-heading panel-info">
          <h3 class=" text-center ">Visión</h3>
        </div>
        <div class="class= card h-100">
          <div class="card-body p-4 ">
            <p class="h4 container px-4 px-lg-5 mt-5" align="justify">
              Nuestra visión es ser una Fundación reconocida por su nivel de responsabilidad
              y comprometida en ayudar a animales callejeros, a través del desarrollo humano
              y transformando el entorno de nuestra comunidad de la Ciudad de México. Cuya
              manera de actuar se basa a través de nuestros valores, así como en calidad,
              transparencia eficiencia y servicio.
            </p>
          </div>
        </div>
      </div>
      <!-- objetivo -->
      <div class="panel panel-default">
        <div class="panel-heading panel-info">
          <h3 class=" text-center ">Objetivo</h3>
        </div>
        <div class="class= card h-100">
          <div class="card-body p-4 ">
            <p class="h4 container px-4 px-lg-5 mt-5" align="justify">
              Brindar servicios de atención veterinaria a personas de escasos recursos
              y a rescatistas independientes tomando en cuenta la aplicación de un estudio
              socioeconómico que permita generar donativos para seguir apoyando el proyecto
              de la cadena de hospitales veterinarios, los cuales financiarán un proyecto de
              educación universitaria.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div> <!-- /container -->

  <!--ubicacion-->
  <div class="container px-5 px-lg-5 mt-5" id="main">
    <div class="row gx-5 gx-lg-5 row-cols-2 justify-content-center">
      <div class="col 12">
        <div class="panel panel-default">
          <div class="panel-heading panel-info">
            <h3 class="text-center">Ubicacion</h3>
          </div>
          <div class="class= card h-100">
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3762.4005546450667!2d-99.1891993!3d19.4382896!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d1f8a94749bce7%3A0x7fa277f1238cdfcc!2sAv.%20Ej%C3%A9rcito%20Nacional%20Mexicano%20359%2C%20Granada%2C%20Miguel%20Hidalgo%2C%2011520%20Ciudad%20de%20M%C3%A9xico%2C%20CDMX!5e0!3m2!1ses-419!2smx!4v1638136993239!5m2!1ses-419!2smx" width="100%" height="auto" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div> <!-- /container -->

  <!----------- Footer ------------>
  <footer>
    <table class="table footer-table footer-table-td">
      <tbody>
        <tr>
          <td><a class="a" style="text-decoration: none;" href="terminos&condiciones.php">Terminos & Condiciones</a></td>
          <td><a class="a" style="text-decoration: none;" href="privacidad.php">Politica de privacidad</a></td>
          <td><a class="a" style="text-decoration: none;" href="index.php">Acerca de</a></td>
          <td><a class="a" style="text-decoration: none;" href="soporte.php">Ayuda</a></td>
        </tr>
        <tr>
          <td><a class="a" style="text-decoration: none;" href="https://www.facebook.com/Fundaci%C3%B3n-Albornoz-Jim%C3%A9nez-1000658333438569/" target="_blank">Facebook</a></td>
          <td><a class="a" style="text-decoration: none;" href="https://twitter.com/fundacion_j?t=h69P53_6IAjIUPqhJycW7Q&s=09" target="_blank">Twitter </a></td>
          <td><a class="a" style="text-decoration: none;"> instagram </a></li>
          <td>
            <p class="a" style="text-decoration: none;"> Copyright (c) 2021</p>
            </li>
        </tr>
      </tbody>
    </table>
  </footer>

  <!-- JavaScript -->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>