<?php
require 'conexion.php';
session_start();
require 'funciones.php';
if (isset($_SESSION['usuario'])) {
  $email = $_SESSION['usuario'];
  $query = $conexion->prepare("UPDATE usuarios  SET estatus_actual_id = '2' WHERE correo ='$email'");
  $query->execute();
  $usuarios = $query->fetchAll(PDO::FETCH_ASSOC);
  foreach ($usuarios as $usuario) {
    $nombre_usuario = $usuario['nombre_usuario'];
    $correo = $usuario['correo'];
    $telefono = $usuario['telefono'];
    $direccion = $usuario['direccion'];
  }

?>
  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fundación Albornoz Jiménez A.C.</title>

    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="shorcut icon" type="image/x-icon" href="assets/imagenes/Fundacion.ico">
  </head>

  <body>
    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="panel/index.php">FAJ</a>
        </div>
      </div>
    </nav>
    <div class="container" id="main">
      <div class="row">
        <div class="jumbotron">
          <p>Gracias por su consideración, nos pondremos en contacto con usted con información sobre su solicitud</p>
          <p>
            <a href="panel/index.php">Regresar</a>
          </p>
        </div>
      </div>
    </div> <!-- /container -->

    <!-- JavaScript-->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script type='text/javascript'>
      $(function() {
        $(document).bind("contextmenu", function(e) {
          return false;
        });
      });
    </script>
  </body>

  </html>
<?PHP
} else {
  header('Location: login.php'); 
  die();
}
?>