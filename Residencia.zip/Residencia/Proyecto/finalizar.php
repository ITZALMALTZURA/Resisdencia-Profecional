<?php
require_once 'conexion.php';
session_start();

if (isset($_SESSION['usuario'])) {
  require 'funciones.php';
  $email_sesion = $_SESSION['usuario'];
  $query_sesion = $conexion->prepare("SELECT * FROM usuarios WHERE correo ='$email_sesion'");
  $query_sesion->execute();
  $sesion_usuarios = $query_sesion->fetchAll(PDO::FETCH_ASSOC);
  foreach ($sesion_usuarios as $sesion_usuario) {
    $nombre_usuario = $sesion_usuario['nombre_usuario'];
    $correo = $sesion_usuario['correo'];
    $telefono = $sesion_usuario['telefono'];
    $direccion = $sesion_usuario['direccion'];
    $sobrenombre = $sesion_usuario['sobrenombre'];
  }



?>
  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fundación Albornoz Jiménez A.C.</title>

    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="shorcut icon" type="image/x-icon" href="assets/imagenes/Fundacion.ico">
    <link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css" />

    <script type="text/javascript" src="DataTables/datatables.min.js"></script>
  </head>

  <body>

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand">FAJ</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav pull-right">
            <li>
              <a href="carrito.php" class="btn">Solicitudes<span class="badge"> <?php print cantidadMascota(); ?></span></a>
            </li>
          </ul>
        </div>
        <!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container" id="main">
      <div class="main-form">
        <div class="row">
          <div class="col-md-12">
            <fieldset>
              <legend>Completar Datos</legend>
              <form action="completar_solicitud.php" method="post">
                <div class="form-group">
                  <label>Nombre Completo</label>
                  <input value="<?php echo $nombre_usuario ?>" type="text" class="form-control" name="nombre_usuario" readonly>
                </div>
                <div class="form-group">
                  <label>Correo</label>
                  <input type="email" class="form-control" value="<?php echo $correo; ?>" name="correo" readonly>
                </div>
                <div class="form-group">
                  <label>Teléfono</label>
                  <input type="text" class="form-control" value="<?php echo $telefono; ?>" name="telefono" readonly>
                </div>
                <div class="form-group">
                  <label>Direccion</label>
                  <input type="text" class="form-control" value="<?php echo $direccion; ?>" name="direccion" readonly>
                </div>
                <div class="form-group">
                  <label for="motivo">Motivos de la solicitud</label>
                  <textarea placeholder="Esto es muy importante para la solicitud" minlength="15" maxlength="500" name="motivo" id="motivo" class="form-control" rows="4" pattern="[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]{15,500}" title="ingrese un motivo valido" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Enviar</button>
              </form>
            </fieldset>
          </div>
        </div>
      </div>

    </div> <!-- /container -->

    <!--JavaScript -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

  </body>

  </html>

<?php
} else {
  header('Location: login.php'); 
  die();
}
?>