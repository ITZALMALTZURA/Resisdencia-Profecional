<?php session_start();

if (isset($_SESSION['administrador'])) {

  require '../../conexion.php';
?>
  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fundacion Albornoz Jimenez A.C.</title>

    <!-- CSS -->
    <link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/estilos.css">
    <link rel="shorcut icon" type="image/x-icon" href="../../assets/imagenes/Fundacion.ico">
    <link rel="icon" href="../../assets/imagenes/logo.ico">
  </head>

  <body>

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="../dashboard.php">Fundacion Albornoz Jimenez A.C.</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav pull-right">
            <li class="active">
              <a href="index.php" class="btn">Informacion de la solicitud</a>
            </li>
            <li>
              <a href="index.php" class="btn">Regresar</a>
            </li>

            <li>
              <a href="../../Cerrar_session.php" class="btn">CERRAR SESION</a>
            </li>
          </ul>




        </div>
        <!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container" id="main">
      <div class="row">
        <div class="col-md-12">
          <fieldset>
            <?php
            require '../../vendor/autoload.php';
            $id = $_GET['id'];
            $pedido = new fundacion\Solicitud;

            $info_pedido = $pedido->mostrarPorId($id);

            $info_detalle_pedido = $pedido->mostrarDetallePorIdSolicitud($id);

            ?>


            <legend>Información de la Solicitud</legend>
            <div class="form-group">
              <label>Nombre</label>
              <input value="<?php print $info_pedido['nombre_usuario'] ?>" type="text" class="form-control" readonly>
            </div>

            <div class="form-group">
              <label>Email</label>
              <input value="<?php print $info_pedido['correo'] ?>" type="text" class="form-control" readonly>
            </div>
            <div class="form-group">
              <label>Motivo de solicitud</label>
              <input value="<?php print $info_pedido['motivo'] ?>" type="text" class="form-control" readonly>
            </div>
            <div class="form-group">
              <label>Fecha</label>
              <input value="<?php print $info_pedido['fecha'] ?>" type="text" class="form-control" readonly>
            </div>



            <hr>
            Mascotas Solicitadas
            <hr>
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Nombre</th>
                  <th>Foto</th>
                  <th>Sexo</th>
                  <th>Edad</th>
                  <th>Raza</th>
                </tr>
              </thead>
              <tbody>
                <?php


                $cantidad = count($info_detalle_pedido);
                if ($cantidad > 0) {
                  $c = 0;
                  for ($i = 0; $i < $cantidad; $i++) {
                    $c++;
                    $item = $info_detalle_pedido[$i];
                    $total = $item['cantidad'];
                ?>


                    <tr>
                      <td><?php print $c ?></td>
                      <td><?php print $item['nombre_m'] ?></td>
                      <td>
                        <?php
                        $foto = '../../upload/' . $item['foto'];
                        if (file_exists($foto)) {
                        ?>
                          <img src="<?php print $foto; ?>" width="35">
                        <?php } else { ?>
                          SIN FOTO
                        <?php } ?>
                      </td>
                      <td><?php print $item['sexo'] ?></td>
                      <td><?php print $item['edad'] ?></td>
                      <td><?php print $item['raza'] ?></td>
                    </tr>

                  <?php
                  }
                } else {

                  ?>
                  <tr>
                    <td colspan="6">NO HAY REGISTROS</td>
                  </tr>

                <?php } ?>


              </tbody>

            </table>
            <div class="col-md-3">
              <div class="form-group">
                <label>Total de Solicitudes</label>
                <input value="<?php print $info_pedido['total'] ?>" type="text" class="form-control" readonly>
              </div>
            </div>

          </fieldset>





        </div>


      </div>
    </div>


    </div> <!-- /container -->


    <!-- JavaScript-->
    <script src="../../assets/js/jquery.min.js"></script>
    <script src="../../assets/js/bootstrap.min.js"></script>
    <script>
      $('#btnImprimir').on('click', function() {

        window.print();

        return false;

      })
    </script>
    <script type='text/javascript'>
      $(function() {
        $(document).bind("contextmenu", function(e) {
          return false;
        });
      });
    </script>

  </body>

  </html>

<?php
} else {
  header('Location: ../../login.php');
  die();
}

?>