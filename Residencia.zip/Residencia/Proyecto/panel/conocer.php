<?php session_start();

if (isset($_SESSION['usuario'])) {
    require '../funciones.php';
    require '../conexion.php';

    $email_sesion = $_SESSION['usuario'];
    $query_sesion = $conexion->prepare("SELECT * FROM usuarios WHERE correo ='$email_sesion'");
    $query_sesion->execute();
    $sesion_usuarios = $query_sesion->fetchAll(PDO::FETCH_ASSOC);
    foreach ($sesion_usuarios as $sesion_usuario) {
        $sobrenombre = $sesion_usuario['sobrenombre'];
    }
?>

    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="description" content="">
        <meta name="author" content="">


        <title>Fundación Albornoz Jiménez A.C.</title>

        <!-- CSS -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/estilos.css">
        <link rel="shorcut icon" type="image/x-icon" href="../assets/imagenes/Fundacion.ico">
        <link rel="stylesheet" href="../Css/toastr.min.css">
    </head>

    <body>

        <!-- Fixed navbar -->
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">Regresar</a>
                </div>

                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav pull-right">
                        <li class="active">
                            <a href="conocer.php" class="btn">Conociendo a<span class="badge"></span></a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $sobrenombre ?> <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="usuario/solicitud/index.php">Mis solicitudes</a></li>
                                <li><a href="usuario/actualizar_usuario.php">Mis datos</a></li>
                                <li><a href="usuario/actualizar_clave.php">Cambiar contraseña</a></li>
                                <li><a href="../Cerrar_session.php">Salir</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <!--/.nav-collapse -->
            </div>
        </nav>
        <div class="container" id="main">
            <div class="row">

                <?php
                require '../vendor/autoload.php';
                $id = $_GET['id'];
                $mascota = new fundacion\Mascota;
                $item = $mascota->ConocerPorId($id);

                ?>

                <div class="col-md-12">
                    <fieldset>

                        <legend>Información sobre <?php print $item['nombre_m'] ?></legend>
                        <div class="form-group">
                            <label>Nombre</label>
                            <input value="<?php print $item['nombre_m'] ?>" type="text" class="form-control" readonly>
                        </div>
                        <div class="form-group">
                            <label>Especie</label>
                            <input value="<?php print $item['nombre_e'] ?>" type="text" class="form-control" readonly>
                        </div>
                        <div class="form-group">
                            <label>Sexo</label>
                            <input value="<?php print $item['sexo'] ?>" type="text" class="form-control" readonly>
                        </div>
                        <div class="form-group">
                            <label>Edad</label>
                            <input value="<?php print $item['edad'] ?>" type="text" class="form-control" readonly>
                        </div>
                        <div class="form-group">
                            <label>Raza</label>
                            <input value="<?php print $item['raza'] ?>" type="text" class="form-control" readonly>
                        </div>
                        <div class="form-group">
                            <label>Color</label>
                            <input value="<?php print $item['color'] ?>" type="text" class="form-control" readonly>
                        </div>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Descripcion</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php print $item['descripcion'] ?></td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Foto</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <?php
                                        $foto = '../upload/' . $item['foto'];
                                        if (file_exists($foto)) {
                                        ?>
                                            <img class="img-resposive center-block" src="<?php print $foto; ?>">
                                        <?php } else { ?>
                                            <img class="img-resposive center-block" src="../assets/imagenes/not-found.jpg">
                                        <?php } ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                    </fieldset>

                    <div class="row">
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end ">
                            <a href="index.php" class="btn btn-info me-md-2">
                                <span class="glyphicon "></span>Regresar</a>
                            <a href="../carrito.php?id=<?php echo $item['id'] ?>" class="btn btn-success">
                                <span class="glyphicon "></span>Adoptar</a>
                        </div>
                    </div><br>
                </div>
            </div>
        </div>

    </body>
    <!--  JavaScript-->
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>

    </html>
<?php
} else {
    header('Location: ../login.php'); 
  die();
}

?>