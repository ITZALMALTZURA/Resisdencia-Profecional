<?php session_start();
require '../conexion.php';

$query = "SELECT * FROM mascotas WHERE estatus_id = 2 ";

if (isset($_POST['mascotas'])) {
    $buscar = $_POST['mascotas'];

    $query = $conexion->prepare("SELECT m.id, nombre_m ,sexo, color, edad, nombre_s, descripcion, foto, nombre_e, raza, fecha, telefono_dueno_ant, nombre_dueno_ant FROM mascotas m 
INNER JOIN especies e ON m.especie_id = e.id 
        INNER JOIN estatus_mascotas s ON m.estatus_id = s.id_estatus 
WHERE m.estatus_id = 2 AND nombre_m LIKE LOWER('%" . $buscar . "%') OR nombre_e LIKE LOWER ('%" . $buscar . "%') ");
    $query->execute();
    $resultados = $query->fetchAll(PDO::FETCH_ASSOC);

    $cantidad = count($resultados);
    if ($cantidad > 0) {
        for ($i = 0; $i < $cantidad; $i++) {
            $resultado = $resultados[$i]; ?>

            <?php
            if (isset($_SESSION['usuario'])) {
            ?>

                <div class="col 12 col-sm-6 col-md-6 col-lg-4 col-xl-3 col-xxl-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h1 class="text-center titulo-pelicula"><?php print $resultado['nombre_m'] ?></h1>
                        </div>
                        <div class="panel-body img-responsive center-block">
                            <?php
                            $foto = '../upload/' . $resultado['foto'];
                            if (file_exists($foto)) {
                            ?>
                                <img class="img-resposive center-block" src="<?php print $foto; ?>">
                            <?php } else { ?>
                                <img class="img-resposive center-block" src="../assets/imagenes/not-found.jpg">
                            <?php } ?>
                        </div>
                        <div class="panel-body">
                            <p class="p titulo-pelicula" align="justify"><small>Sexo: <?php print $resultado['sexo'] ?></small></p>

                            <p class="p titulo-pelicula" align="justify"><small>Edad: <?php print $resultado['edad'] ?></small></p>

                            <p class="p titulo-pelicula" align="justify"><small>Raza: <?php print $resultado['raza'] ?></small></p>
                        </div>


                        <div class="panel-footer ">
                            <a href="conocer.php?id=<?php print $resultado['id'] ?>" class="btn btn-info btn-block">
                                <span class="glyphicon "></span>Saber mas</a>
                            <a href="../carrito.php?id=<?php print $resultado['id'] ?>" class="btn btn-success btn-block">
                                <span class="glyphicon "></span>Adoptar</a>
                        </div>
                    </div>
                </div>
            <?php
            } else {
                header('Location: ../login.php');
                die();
            }

            ?>
        <?php } ?>
    <?php } else { ?>
        <tr>
            <td colspan="7">No hay mascotas intente nuevamente</td>
        </tr>
    <?php } ?>
    <?php } else {
    $query = $conexion->prepare("SELECT * FROM mascotas WHERE estatus_id = 2 ");
    $query->execute();
    $resultados = $query->fetchAll(PDO::FETCH_ASSOC);
    $cantidad = count($resultados);
    if ($cantidad > 0) {
        for ($i = 0; $i < $cantidad; $i++) {
            $resultado = $resultados[$i];
    ?>

            <?php

            if (isset($_SESSION['usuario'])) {


            ?>


                <div class="col 12 col-sm-6 col-md-6 col-lg-4 col-xl-3 col-xxl-3">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h1 class="text-center titulo-pelicula"><?php print $resultado['nombre_m'] ?></h1>
                        </div>
                        <div class="panel-body img-responsive center-block">
                            <?php
                            $foto = '../upload/' . $resultado['foto'];
                            if (file_exists($foto)) {
                            ?>
                                <img class="img-resposive center-block" src="<?php print $foto; ?>">
                            <?php } else { ?>
                                <img class="img-resposive center-block" src="../assets/imagenes/not-found.jpg">
                            <?php } ?>
                        </div>
                        <div class="panel-body">
                            <p class="p titulo-pelicula" align="justify"><small>Sexo: <?php print $resultado['sexo'] ?></small></p>

                            <p class="p titulo-pelicula" align="justify"><small>Edad: <?php print $resultado['edad'] ?></small></p>

                            <p class="p titulo-pelicula" align="justify"><small>Raza: <?php print $resultado['raza'] ?></small></p>
                        </div>


                        <div class="panel-footer ">
                            <a href="conocer.php?id=<?php print $resultado['id'] ?>" class="btn btn-info btn-block">
                                <span class="glyphicon "></span>Saber mas</a>
                            <a href="../carrito.php?id=<?php print $resultado['id'] ?>" class="btn btn-success btn-block">
                                <span class="glyphicon "></span>Adoptar</a>
                        </div>
                    </div>
                </div>


        <?php
            }
        }


        ?>


<?php }
} ?>