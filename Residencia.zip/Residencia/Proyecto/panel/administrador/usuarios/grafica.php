<?php session_start();

if (isset($_SESSION['administrador'])) {

    require '../../../conexion.php';
    $email_sesion = $_SESSION['administrador'];
    $query_sesion = $conexion->prepare("SELECT * FROM administrador WHERE correo ='$email_sesion'");
    $query_sesion->execute();
    $sesion_administradores = $query_sesion->fetchAll(PDO::FETCH_ASSOC);
    foreach ($sesion_administradores as $sesion_administrador) {
        $sobrenombre = $sesion_administrador['sobrenombre'];
    }

?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Fundación Albornoz Jiménez A.C.</title>

        <!-- CSS -->
        <link rel="stylesheet" href="../../../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../../../assets/css/estilos.css">
        <link rel="shorcut icon" type="image/x-icon" href="../../../assets/imagenes/Fundacion.ico">
    </head>

    <body>

        <!-- Fixed navbar -->
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">Regresar</a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav pull-right">
                        <li class="active" class="dropdown">
                            <a href="index.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Ayuda<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="index.php">General</a></li>
                                <li><a href="activas.php">Activas</a></li>
                                <li><a href="desactivas.php">Desactivas</a></li>
                                <li><a href="suspendidas.php">Suspendidas</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $sobrenombre ?> <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="../actualizar_administrador.php">Mis datos</a></li>
                                <li><a href="../actualizar_clave.php">Cambiar contraseña</a></li>
                                <li><a href="../../../Cerrar_session.php">Salir</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <!--/.nav-collapse -->
            </div>
        </nav>



        <?php
        require '../../../vendor/autoload.php';
        $usuario = new fundacion\Usuario;
        //por estatus
        $general = $usuario->graficageneral();
        $activas = $usuario->graficaActivas();
        $desactivas = $usuario->graficaDesactivas();
        $suspendidas = $usuario->graficaSuspendidas();

        $grafica_g = ((float)$general * 100) / $general; //regla de tres
        $grafica_g = round($grafica_g, 0); // Quitar los decimales
        $grafica_a = ((float)$activas * 100) / $general;
        $grafica_a = round($grafica_a, 0);
        $grafica_d = ((float)$desactivas * 100) / $general;
        $grafica_d = round($grafica_d, 0);
        $grafica_s = ((float)$suspendidas * 100) / $general;
        $grafica_s = round($grafica_s, 0);
        //actualizadas
        $actualizadas = $usuario->graficaActualizadas();

        $grafica_ac = ((float)$actualizadas * 100) / $general; //regla de tres
        $grafica_ac = round($grafica_ac, 0); // Quitar los decimales

        $sinactualizar = $general - $actualizadas; //regla de tres
        $grafica_sa = ((float)$sinactualizar * 100) / $general; //regla de tres
        $grafica_sa = round($grafica_sa, 0); // Quitar los decimales
        ?>
        <div class="container px-5 px-lg-5 mt-5" id="main">
            <div class="row gx-5 gx-lg-5 row-cols-2 justify-content-center">
                <!--cards / Grafica por estatus-->
                <div class="col 12 ">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-info">
                            <h3 class=" text-center ">Grafica de cuentas por estatus</h3>
                        </div>
                        <!--Grafica general-->
                        <div class="class= card h-100">
                            <div class="card-body p-4 ">
                                <div class="h4 container px-4 px-lg-5 mt-5" align="justify">
                                    <label>Total de cuentas = <?php print $general ?></label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-success progress-bar-striped" title="<?php echo $grafica_a ?>%" style='width: <?php echo $grafica_a ?>%'>
                                        </div>
                                        <div class="progress-bar progress-bar-warning progress-bar-striped" title="<?php echo $grafica_d ?>%" style='width: <?php echo $grafica_d ?>%'>
                                        </div>
                                        <div class="progress-bar progress-bar-danger progress-bar-striped" title="<?php echo $grafica_s ?>%" style='width: <?php echo $grafica_s ?>%'>
                                        </div>
                                    </div>
                                    <!--Graficas individuales-->
                                    <label>Cuentas activas <?php print $activas ?> = <?php print $grafica_a ?> %</label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style='width: <?php echo $grafica_a ?>%'>
                                        </div>
                                    </div>
                                    <label>Cuentas desactivas <?php print $desactivas ?> = <?php print $grafica_d ?> % </label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style='width: <?php echo $grafica_d ?>%'>
                                        </div>
                                    </div>
                                    <label>Cuentas suspendidas <?php print $suspendidas ?> = <?php print $grafica_s ?> %</label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style='width: <?php echo $grafica_s ?>%'>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--cards / Grafica por categoria-->

                    <div class="panel panel-default">
                        <div class="panel-heading panel-info">
                            <h3 class=" text-center ">Grafica de cuentas actualizadas</h3>
                        </div>
                        <!--Grafica general-->
                        <div class="class= card h-100">
                            <div class="card-body p-4 ">
                                <div class="h4 container px-4 px-lg-5 mt-5" align="justify">
                                    <label>Total cuentas = <?php print $general ?></label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-success progress-bar-striped" title="<?php echo $grafica_sa ?>%" style='width: <?php echo $grafica_sa ?>%'>
                                        </div>
                                        <div class="progress-bar progress-bar-danger progress-bar-striped" title="<?php echo $grafica_ac ?>%" style='width: <?php echo $grafica_ac ?>%'>
                                        </div>
                                    </div>
                                    <!--Graficas individuales-->
                                    <label>Cuentas sin actualizar <?php print $sinactualizar ?> = <?php print $grafica_sa ?> %</label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style='width: <?php echo $grafica_sa ?>%'>
                                        </div>
                                    </div>
                                    <label>Cuentas actualizadas <?php print $actualizadas ?> = <?php print $grafica_ac ?> %</label>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style='width: <?php echo $grafica_ac ?>%'>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </body>
    <!-- JavaScript -->
    <script src="../../../assets/js/jquery.min.js"></script>
    <script src="../../../assets/js/bootstrap.min.js"></script>

    </html>
<?php
} else {
    header('Location: ../../../login.php');
    die();
}

?>