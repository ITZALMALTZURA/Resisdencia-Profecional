<?php
          require '../../../vendor/autoload.php';
          $id = $_GET['id'];
          $activar = new fundacion\Usuario;
          $info_activar= $activar->activar($id);
          header('Location: index.php');    
         
?>