<?php
require_once '../../../vendor/autoload.php';

$usuario = new fundacion\Usuario;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    if ($_POST['accion'] === 'Actualizar') {

        if (empty($_POST['nombre_usuario']))
            exit('Completar campo nombre');

        if (empty($_POST['correo']))
            exit('Completar campo correo');

        if (empty($_POST['telefono']))
            exit('Completar campo telefono');

        if (!is_numeric($_POST['telefono']))
            exit('ingresar un numero válido');

        if (empty($_POST['direccion']))
            exit('Completar campo direccion');



        $_params = array(
            'nombre_usuario' => $_POST['nombre_usuario'],
            'correo' => $_POST['correo'],
            'telefono' => $_POST['telefono'],
            'direccion' => $_POST['direccion'],
            'id' => $_POST['id'],
            'administrador_id' => $_POST['administrador_id'],
            'fecha' => date("Y-m-d H:i:s")
        );

        $rpt = $usuario->actualizarUsuario($_params);

        if ($rpt)
            header('Location: index.php');
        else
            print 'Error al registrar al usuario';
    }
}
