<?php session_start();


if (isset($_SESSION['administrador'])) {
  require_once '../../../conexion.php';
  $email_sesion = $_SESSION['administrador'];
  $query_sesion = $conexion->prepare("SELECT * FROM administrador WHERE correo ='$email_sesion'");
  $query_sesion->execute();
  $sesion_administradores = $query_sesion->fetchAll(PDO::FETCH_ASSOC);
  foreach ($sesion_administradores as $sesion_administrador) {
    $administrador_id = $sesion_administrador['id'];
    $sobrenombre = $sesion_administrador['sobrenombre'];
  }

?>
  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fundación Albornoz Jiménez A.C.</title>

    <!-- CSS -->
    <link rel="stylesheet" href="../../../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../assets/css/estilos.css">
    <link rel="shorcut icon" type="image/x-icon" href="../../../assets/imagenes/Fundacion.ico">
  </head>

  <body>

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">Regresar</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav pull-right">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $sobrenombre ?> <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="actualizar_clave.php">Cambiar contraseña</a></li>
                <li><a href="../../../Cerrar_session.php">Salir</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
      <!--/.nav-collapse -->
    </nav>

    <div class="container" id="main">
      <div class="main-form">
        <div class="row">
          <div class="col-md-12">
            <fieldset>
              <?php
              require '../../../vendor/autoload.php';
              $id = $_GET['id'];
              $ayuda = new fundacion\Usuario;

              $item = $ayuda->mostrarPorId($id);


              ?>
              <form method="POST" action="acciones.php" enctype="multipart/form-data">
                <legend>Informacion del administrador</legend>
                <div class="form-group">
                  <label>Este administrador se registrara al actualizar al usuario</label>
                  <input value="<?php echo $administrador_id; ?>" type="text" class="form-control" name="administrador_id" readonly>
                </div>
                <legend>Informacion del usuario</legend>
                <div class="form-group">
                  <label>Id del usuario</label>
                  <input value="<?php echo $item['id']; ?>" type="text" class="form-control" name="id" readonly>
                </div>
                <div class="form-group">
                  <label for="nombre_usuario">Nombre Completo</label>
                  <input value="<?php echo $item['nombre_usuario']; ?>" minlength="2" maxlength="100" class="form-control" placeholder="Ingresa tu nombre completo" name="nombre_usuario" id="nombre_usuario" pattern="[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-]{2,100}" title="ingrese un nombre valido" required>
                </div>
                <div class="form-group">
                  <label for="correo">Correo</label>
                  <input value="<?php print $item['correo']; ?>" type="email" minlength="10" maxlength="320" class="form-control" placeholder="Ingresa tu email" name="correo" id="correo" pattern="[^[a-zA-Z0-9.!#$%&*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$]{10,320}" title="ingrese un correo valido" required>
                </div>
                <div class="form-group">
                  <label for="telefono">Teléfono</label>
                  <input value="<?php print $item['telefono']; ?>" type="tel" minlength="10" maxlength="10" class="form-control" placeholder="Ingresa tu numero telefonico" pattern="[0-9]{1,10}" name="telefono" id="telefono" title="ingrese un numero telefonico valido" required>
                </div>
                <div class="form-group">
                  <label for="direccion">Direccion</label>
                  <input value="<?php print $item['direccion']; ?>" type="text-area" class="form-control bg-dark-x border-0" placeholder="Chapultepec Morales, Granada, Miguel Hidalgo, 11520 Ciudad de México,CDMX" name="direccion" id="direccion" pattern="[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-/\]" title="Ingrese una direccion validad" required>
                </div>
                <div class="row">
                  <div class="d-grid gap-2 d-md-flex justify-content-md-end ">
                    <input type="submit" class="btn btn-info" name="accion" value="Actualizar">
                    <a href="index.php" class="btn btn-danger">Cancelar</a>
                  </div>
                </div>
              </form>
            </fieldset><br>
          </div>
        </div>
      </div>
    </div> <!-- /container -->

    <!--JavaScript -->
    <script src="../../../assets/js/jquery.min.js"></script>
    <script src="../../../assets/js/bootstrap.min.js"></script>

  </body>

  </html>

<?php
} else {
  header('Location: ../../../login.php');
  die();
}
?>