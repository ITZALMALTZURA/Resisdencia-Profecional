<?php
require '../../../conexion.php';
session_start();

if (isset($_SESSION['usuario'])) {
  
  $email_sesion = $_SESSION['usuario'];
  $query_sesion = $conexion->prepare("SELECT s.id,  s.total, s.fecha,  es.nombre, p.nombre_usuario, p.correo, p.telefono FROM
  solicitudes s
  INNER JOIN estatus_solicitud es ON s.estatus_solicitud_id = es.id
  INNER JOIN postulados p ON s.postulado_id = p.id
  WHERE p.correo = '$email_sesion' ORDER BY s.id DESC");
  $query_sesion->execute();
  $sesion_usuarios = $query_sesion->fetchAll(PDO::FETCH_ASSOC);


  $email = $_SESSION['usuario'];
  $query = $conexion->prepare("SELECT * FROM usuarios WHERE correo ='$email'");
  $query->execute();
  $usuarios = $query->fetchAll(PDO::FETCH_ASSOC);
  foreach ($usuarios as $usuario) {
    $sobrenombre = $usuario['sobrenombre'];
  }


?>

  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fundación Albornoz Jiménez A.C.</title>

    <!-- CSS -->
    <link rel="stylesheet" href="../../../assets/css/bootstrap.min.css">
    </link>
    <link rel="stylesheet" href="../../../assets/css/estilos.css">
    </link>
    <link rel="shorcut icon" type="image/x-icon" href="../../../assets/imagenes/Fundacion.ico">
    </link>
    <link rel="stylesheet" type="text/css" href="../../../DataTables/datatables.min.css" />
    </link>
    <link rel="stylesheet" type="text/css" href="../../../DataTables/Responsive-2.2.9/css/responsive.dataTables.min.css" />
    </link>
  </head>

  <body>

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="../../index.php">Regresar</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav pull-right">
            <li class="active">
              <a href="index.php" class="btn">Solicitudes</a>
            </li>
            <li>
              <a href="../../index.php" class="btn">Mascotas</a>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $sobrenombre ?><span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="../actualizar_usuario.php">Mis Datos</a></li>
                <li><a href="../actualizar_clave.php">Cambiar contraseña</a></li>
                <li><a href="../eliminar_cuenta.php">Eliminar cuenta</a></li>
                <li><a href="../../../Cerrar_session.php">Salir</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
      <!--/.nav-collapse -->
    </nav>

    <div class="container" id="main">
      <div class="row">
        <div class="col-md-12">
          <fieldset>
            <legend>Listado de solicitudes</legend>
            <table id="tablax" class="table table-bordered display responsive nowrap" cellspacing="0">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Postulaciones</th>
                  <th>Fecha</th>
                  <th>Nombre</th>
                  <th>Correo</th>
                  <th>Telefono</th>
                  <th>Estatus</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?PHP
                foreach ($sesion_usuarios as $sesion_usuario => $value) {
                ?>

                  <tr>
                    <td><?php print $value['id'] ?></td>
                    <td><?php print $value['total'] ?></td>
                    <td><?php print $value['fecha'] ?></td>
                    <td><?php print $value['nombre_usuario'] ?> </td>
                    <td><?php print $value['correo'] ?></td>
                    <td><?php print $value['telefono'] ?> </td>
                    <td><?php print $value['nombre'] ?></td>
                    <td class="text-center">
                      <a href="ver.php?id=<?php print $value['id'] ?>" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-download-alt"></span></a>
                    </td>
                  </tr>
                <?php
                }
                ?>
              </tbody>
            </table>
          </fieldset>
        </div>
      </div>
    </div> <!-- /container -->

    <!-- JavaScript -->
    <script src="../../../assets/js/jquery.min.js"></script>
    <script src="../../../assets/js/bootstrap.min.js"></script>
    <!-- Data tables -->

    <script type="text/javascript" src="../../../DataTables/datatables.min.js"></script>
    <script type="text/javascript" src="../../../DataTables/Responsive-2.2.9/js/dataTables.responsive.min.js"></script>
    <script>
      $(document).ready(function() {
        $('#tablax').DataTable({
          responsive: true,
          language: {
            processing: "Tratamiento en curso...",
            search: "Buscar&nbsp;:",
            lengthMenu: "Agrupar de _MENU_ Registros",
            info: "Mostrando del Registro _START_ al _END_ de un total de _TOTAL_Registros",
            infoEmpty: "No existen datos.",
            infoFiltered: "(filtrado de _MAX_ elementos en total)",
            infoPostFix: "",
            loadingRecords: "Cargando...",
            zeroRecords: "No se encontraron datos con tu busqueda",
            emptyTable: "No hay datos disponibles en la tabla.",
            paginate: {
              first: "Primero",
              previous: "Anterior",
              next: "Siguiente",
              last: "Ultimo"
            },
            aria: {
              sortAscending: ": active para ordenar la columna en orden ascendente",
              sortDescending: ": active para ordenar la columna en orden descendente"
            },
          }
        });
      });
    </script>
    <script type='text/javascript'>
      $(function() {
        $(document).bind("contextmenu", function(e) {
          return false;
        });
      });
    </script>
  </body>

  </html>
<?php
} else {
  header('Location: ../../../login.php'); 
  die();
}



?>