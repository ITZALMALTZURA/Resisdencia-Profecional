<?php

ob_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Fundación Albornoz Jiménez A.C.</title>

  <!--CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  <link rel="stylesheet" href="../../../assets/css/estilos.css">
  <link rel="shorcut icon" type="image/x-icon" href="../../../assets/imagenes/Fundacion.ico">
</head>

<body>
  <style>
    .watermark {
      position: fixed;

      /** Cambiar las dimensiones de la imagen **/
      display: block;
      margin-left: auto;
      margin-right: auto;
      width: 40%;
      height: auto;
      /**  marca de agua  detrás de cada contenido **/
      z-index: -1000;
      opacity: 0.3;

    }

    div.img {
      display: table;
    }

    div.img img {
      margin: 0;
      padding: 0;
    }

    div.img span {
      line-height: normal;
      font-size: 11px;
      display: table-caption;
      margin: 0;
      padding: 0;
      background: #646464;
      color: white;
      font-style: italic;
      text-align: center;
      position: relative;
      height: 0;
    }

    div.img span span {
      background: rgba(0, 0, 0, 0.4);
      display: block;
      padding: 3px;
      text-shadow: 0 0 15px white;
    }
  </style>


  </head>

  <body>
    <div class="watermark">
      <img src="../../../assets/imagenes/Fundacion.jpeg" />
    </div>

    <div class="container" id="main">
      <div class="row">
        <div class="col-md-12">
          <fieldset>
            <?php
            require '../../../vendor/autoload.php';
            $id = $_GET['id'];
            $pedido = new fundacion\Solicitud;

            $info_pedido = $pedido->mostrarPorId($id);

            $info_detalle_pedido = $pedido->mostrarDetallePorIdSolicitud($id);

            ?>


            <legend>Información de la solicitud  <?php print $info_pedido['id'] ?></legend>
            <br>
            <br>
            <div class="form-group">
              <label>Nombre</label>
              <input value="<?php print $info_pedido['nombre_usuario'] ?>" type="text" class="form-control" readonly>
            </div>
            <div class="form-group">
              <label>Correo</label>
              <input value="<?php print $info_pedido['correo'] ?>" type="text" class="form-control" readonly>
            </div>
            <div class="form-group">
              <label>Telefono</label>
              <input value="<?php print $info_pedido['telefono'] ?>" type="text" class="form-control" readonly>
            </div>
            <div class="form-group">
              <label>Direccion</label>
              <input value="<?php print $info_pedido['direccion'] ?>" type="text" class="form-control" readonly>
            </div>
            <div class="form-group">
              <label>Motivo de solicitud</label>
              <input value="<?php print $info_pedido['motivo'] ?>" type="text" class="form-control" readonly>
            </div>
            <div class="form-group">
              <label>Fecha</label>
              <input value="<?php print $info_pedido['fecha'] ?>" type="text" class="form-control" readonly>
            </div>

            <hr>Mascotas Solicitadas
            <hr>
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Nombre</th>
                  <th>Foto</th>
                  <th>Sexo</th>
                  <th>Edad</th>
                  <th>Raza</th>
                </tr>
              </thead>
              <tbody>
                <?php

                $cantidad = count($info_detalle_pedido);
                if ($cantidad > 0) {
                  $c = 0;
                  for ($i = 0; $i < $cantidad; $i++) {
                    $c++;
                    $item = $info_detalle_pedido[$i];
                    $total = $item['cantidad'];
                ?>
                    <tr>
                      <td><?php print $c ?></td>
                      <td><?php print $item['nombre_m'] ?></td>
                      <td>
                        <?php
                        $foto = '../../../upload/' . $item['foto'];
                        if (file_exists($foto)) {
                        ?>
                          <img src="<?php print $foto; ?>" width="35">
                        <?php } else { ?>
                          SIN FOTO
                        <?php } ?>
                      </td>
                      <td><?php print $item['sexo']  ?></td>
                      <td><?php print $item['edad']  ?></td>
                      <td><?php print $item['raza']  ?></td>
                    </tr>

                  <?php
                  }
                } else {

                  ?>
                  <tr>
                    <td colspan="6">No hay registros</td>
                  </tr>

                <?php } ?>

              </tbody>
            </table>
            <div class="col-md-3">
              <div class="form-group">
                <label>Total de Solicitudes</label>
                <input value="<?php print $info_pedido['total'] ?>" type="text" class="form-control" readonly>
              </div>
            </div>
          </fieldset>
        </div>
      </div>
    </div> <!-- /container -->

    <!-- JavaScript -->
    <script src="../../../assets/js/jquery.min.js"></script>
    <script src="../../../assets/js/bootstrap.min.js"></script>


  </body>

</html>
<?php
$html = ob_get_clean();
//  echo $html;
require_once("../../../dompdf/autoload.inc.php");

use Dompdf\Dompdf;

$dompdf = new Dompdf();

$options = $dompdf->getOptions();
$options->set(array('isRemoteEnabled' => true));
$dompdf->setOptions($options);

$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream('MiSolicitud__' . date('m-d-Y_hia'), array("Attachment" => true));


?>