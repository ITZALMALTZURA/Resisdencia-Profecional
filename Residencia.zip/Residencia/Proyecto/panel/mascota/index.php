<?php session_start();

if (isset($_SESSION['administrador'])) {

  require '../../conexion.php';
  $email_sesion = $_SESSION['administrador'];
  $query_sesion = $conexion->prepare("SELECT * FROM administrador WHERE correo ='$email_sesion'");
  $query_sesion->execute();
  $sesion_administradores = $query_sesion->fetchAll(PDO::FETCH_ASSOC);
  foreach ($sesion_administradores as $sesion_administrador) {
    $sobrenombre = $sesion_administrador['sobrenombre'];
  }
?>
  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fundacion Albornoz Jimenez A.C.</title>

    <!--CSS -->
    <link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/estilos.css">
    <link rel="shorcut icon" type="image/x-icon" href="../../assets/imagenes/favicon.ico">
    <link rel="stylesheet" type="text/css" href="../../DataTables/datatables.min.css" />
    <link rel="stylesheet" type="text/css" href="../../DataTables/Responsive-2.2.9/css/responsive.dataTables.min.css" />
  </head>

  <body>

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="../administrador.php">Regresar</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav pull-right">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Estatus de Mascotas <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="Adoptados.php">Adoptados</a></li>
                <li><a href="Disponibles.php">Disponibles</a></li>
                <li><a href="Nodisponible.php"> No Disponibles</a></li>

              </ul>
            </li>
            <li class="active">
              <a href="index.php" class="btn">Mascotas</a>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $sobrenombre ?> <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#">Mis datos</a></li>
                <li><a href="#">Cambiar contraseña</a></li>
                <li><a href="../../Cerrar_session.php">Salir</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container" id="main">
      <div class="row">
        <div class="col-md-12">
          <div class="pull-right">
            <a href="form_registrar.php" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Nuevo</a>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-12">
          <fieldset>
            <legend>Listado de Mascotas General</legend>
            <table id="tablax" class="table table-bordered display responsive nowrap" cellspacing="0">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Nombre</th>
                  <th>Sexo</th>
                  <th>Color</th>
                  <th>Edad</th>
                  <th>Estatus</th>
                  <th>descripcion</th>
                  <th>Especie</th>
                  <th>raza</th>
                  <th>Fecha de Registro</th>
                  <th>Contacto Dueño Anterior</th>
                  <th>Nombre Dueño Anterior</th>
                  <th class="text-center">Foto</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php
                require '../../vendor/autoload.php';
                $mascota = new fundacion\Mascota;
                $info_mascota = $mascota->mostrar();


                $cantidad = count($info_mascota);
                if ($cantidad > 0) {
                  $c = 0;
                  for ($i = 0; $i < $cantidad; $i++) {
                    $c++;
                    $item = $info_mascota[$i];
                ?>


                    <tr>
                      <td><?php print $c ?></td>
                      <td><?php print $item['nombre_m'] ?></td>
                      <td><?php print $item['sexo'] ?></td>
                      <td><?php print $item['color'] ?></td>
                      <td><?php print $item['edad'] ?></td>
                      <td><?php print $item['nombre_s'] ?></td>
                      <td><?php print $item['descripcion'] ?></td>
                      <td><?php print $item['nombre_e'] ?></td>
                      <td><?php print $item['raza'] ?></td>
                      <td><?php print $item['fecha'] ?></td>
                      <td><?php print $item['telefono_dueno_ant'] ?></td>
                      <td><?php print $item['nombre_dueno_ant'] ?></td>
                      <td class="text-center">
                        <?php
                        $foto = '../../upload/' . $item['foto'];
                        if (file_exists($foto)) {
                        ?>
                          <img src="<?php print $foto; ?>" width="230">
                        <?php } else { ?>
                          SIN FOTO
                        <?php } ?>
                      </td>
                      <td class="text-center">
                        <a href="../acciones.php?id=<?php print $item['id'] ?>" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash" title="Eliminar"></span></a>
                        <a href="form_actualizar.php?id=<?php print $item['id']  ?>" class="btn btn-success btn-sm"><span class="glyphicon glyphicon-edit" title="Actualizar"></span></a>
                      </td>

                    </tr>

                  <?php
                  }
                } else {

                  ?>
                  <tr>
                    <td colspan="6">NO HAY REGISTROS</td>
                  </tr>

                <?php } ?>


              </tbody>

            </table>
          </fieldset>
          <p>Descargar el Reporte:
            <a class="btn btn-primary" href="reporte_general.php"><i class="glyphicon glyphicon-download-alt"></i> Descargar</a>
          </p>

        </div>
      </div>

    </div> <!-- /container -->


    <!--JavaScript -->
    <script src="../../assets/js/jquery.min.js"></script>
    <script src="../../assets/js/bootstrap.min.js"></script>
    <!-- Data tables -->

    <script type="text/javascript" src="../../DataTables/datatables.min.js"></script>
    <script type="text/javascript" src="../../DataTables/Responsive-2.2.9/js/dataTables.responsive.min.js"></script>
    <script>
      $(document).ready(function() {
        $('#tablax').DataTable({
          responsive: true,
          language: {
            processing: "Tratamiento en curso...",
            search: "Buscar&nbsp;:",
            lengthMenu: "Agrupar de _MENU_ items",
            info: "Mostrando del item _START_ al _END_ de un total de _TOTAL_ items",
            infoEmpty: "No existen datos.",
            infoFiltered: "(filtrado de _MAX_ elementos en total)",
            infoPostFix: "",
            loadingRecords: "Cargando...",
            zeroRecords: "No se encontraron datos con tu busqueda",
            emptyTable: "No hay datos disponibles en la tabla.",
            paginate: {
              first: "Primero",
              previous: "Anterior",
              next: "Siguiente",
              last: "Ultimo"
            },
            aria: {
              sortAscending: ": active para ordenar la columna en orden ascendente",
              sortDescending: ": active para ordenar la columna en orden descendente"
            }
          }
        });
      });
    </script>

  </body>

  </html>
<?php
} else {
  header('Location: ../../login.php');
  die();
}

?>